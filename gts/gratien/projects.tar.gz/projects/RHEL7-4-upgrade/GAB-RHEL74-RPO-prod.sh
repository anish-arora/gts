#!/usr/bin/env bash
########################################################################
# Script Name          : GAB-RHEL74-RPO.sh
# Author               : Gratien Dhaese
# Creation Date        : 11-Dec-2017
# Description          : Configuring Yum Repos in
#                        Red Hat Enterprise Linux
# Change History       : Review git log for history of changes
########################################################################

# Trap on Error
set -e

## Variables
########################################################################
# sourced from /etc/jnj-install/config
# listed in the configvars variable on next line
configvars="dmlurl"

# Source the /etc/jnj-install/config file
# Exit if the /etc/jnj-install/config file is not found
if [ ! -f /etc/jnj-install/config ]; then
  echo "ERROR: /etc/jnj/config file not found."
  exit 1
else
  source /etc/jnj-install/config
fi

for configvar in ${configvars}
do
  if [[ -z $(eval "echo \$$configvar") ]]; then
    echo "ERROR: ${configvar} not defined in /etc/jnj-install/config."
    exit 1
  fi
done

## Logging
#####################################################################
logdir=${logdir:-/var/adm/install-logs}
[[ -d $logdir ]] || mkdir -p $logdir
logfile=$logdir/${0##*/}.$(date +%Y%m%d-%H%M%S).log
exec 3>&1 4>&2
trap 'exec 2>&4 1>&3' 0 1 2 3
exec 1>${logfile} 2>&1

tempdir=$(mktemp -d /tmp/jnjtmp.XXXXXXXXXX)
cd ${tempdir}

#syslog
logger -s -- "[$$] $0 start: $(date)"
logger -s -- "[$$] script started in $(pwd)"
logger -s -- "[$$] logfile is in $logfile"

export PS4="+ [\t] "

## Functions
#####################################################################

function cleanup_before_exit() {
  logger -s -- "[$$] $0 end :  $(date)"
  echo "$0 end: $(date)" >&3
  if [[ "${err}" != "0" ]] ; then
    cat ${logfile} >&3
  fi
  cd /tmp && rm -rf ${tempdir}
}

#####################################################################
############################## M A I N ##############################
#####################################################################

echo "
+-------------------------------------------------------------------+
|    Install the repositories to patch a RHEL system                |
|                    Release 7.4                                    |
+-------------------------------------------------------------------+
" >&3

trap cleanup_before_exit EXIT
echo "$0 start: $(date)" >&3

dmlserver=$(grep '^dmlurl' /etc/jnj-install/config | cut -d/ -f3)
if [[ -z ${dmlserver} ]] ; then
  echo "ERROR: dmlserver variable not defined."
  exit 1
fi

### function ###
function base_repos() {

cat > /etc/yum.repos.d/JNJ-rhel-x86_64-server-7-20171018.repo <<-EOFa
[JNJ-rhel-x86_64-server-7-20171018]
name=JNJ-rhel-x86_64-server-7-20171018
baseurl=http://${dmlserver}/yum/JNJ-rhel-x86_64-server-7-20171018/
gpgcheck=1
enabled=1
EOFa
chmod 644 /etc/yum.repos.d/JNJ-rhel-x86_64-server-7-20171018.repo

cat > /etc/yum.repos.d/JNJ-rhel-x86_64-server-optional-7-20171018.repo <<-EOFb
[JNJ-rhel-x86_64-server-optional-7-20171018]
name=JNJ-rhel-x86_64-server-optional-7-20171018
baseurl=http://${dmlserver}/yum/JNJ-rhel-x86_64-server-optional-7-20171018/
sslcacert=/etc/pki/tls/certs/rootca2048bit.pem
gpgcheck=1
enabled=1
EOFb
chmod 644 /etc/yum.repos.d/JNJ-rhel-x86_64-server-optional-7-20171018.repo

cat > /etc/yum.repos.d/JNJ-rhn-tools-rhel-x86_64-server-7-20171018.repo <<-EOFc
[JNJ-rhn-tools-rhel-x86_64-server-7-20171018]
name=JNJ-rhn-tools-rhel-x86_64-server-7-20171018
baseurl=http://${dmlserver}/yum/JNJ-rhn-tools-rhel-x86_64-server-7-20171018/
gpgcheck=1
enabled=1
EOFc
chmod 644 /etc/yum.repos.d/JNJ-rhn-tools-rhel-x86_64-server-7-20171018.repo

cat > /etc/yum.repos.d/RHEL7_4_Agents.repo <<-EOFd
[RHEL7_4_Agents]
name=RHEL7_4_Agents repo for J&J agents
baseurl=http://${dmlserver}/yum/RHEL7_4_Agents/x86_64/
gpgcheck=0
enabled=1
EOFd
chmod 644 /etc/yum.repos.d/RHEL7_4_Agents.repo
}
### end of function ###

# if not registered with Satellite Server include base repos
if [[ ! "$(rhn-channel -b)" =~ "JNJ-rhel-x86_64-server" ]] ; then
  if [ -f /etc/sysconfig/rhn/systemid ] ; then
    rm -rf /etc/sysconfig/rhn/systemid
  fi

  # Disable all existing repos
  yum-config-manager --disable "*"

  #call base repos function
  base_repos
fi

# import rpm gpg keys
rpm --import /etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-*


# Show all rpm gpg keys present on this system:
echo "RPM public GnuPG keys present are:"
rpm -q gpg-pubkey --qf '%{NAME}-%{VERSION}-%{RELEASE}\t%{SUMMARY}\n'

# Re-enable some of our repo's again
if [[ -f /etc/yum.repos.d/gtsc.repo ]] ; then
    yum-config-manager --enable gtsc
fi

if [[ -f /etc/yum.repos.d/epel.repo ]] ; then
    yum-config-manager --enable epel
fi

# echo clear the YUM cache
echo "Cleaning up YUM cache"
yum clean all >/dev/null 2>&1

# Show the repo's useable for patching:
echo "YUM repositories available for patching:"
yum repolist 2>/dev/null

