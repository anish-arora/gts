#! /usr/bin/perl
########################################################################
# Script Name          : GAB-RHEL-IQS.sh
# Author               : SATISH
# Creation Date        : 14-AUG-2016
# Description          : Installation Verification script for Autobuild of
#                        Red Hat Enterprise Linux
########################################################################
# Execute as: perl GAB-RHEL-IQS.sh >GAB-RHEL-IQS.sh.$(date +%Y%m%d-%H%M%S).log
########################################################################

use version;
use File::stat;
$VERSION="7.2.04";
$LAST_MOD_DATE="11-DEC-2017";
$LOGFILE="/root/iq.html";

# need to add check to see if all partitions exist (partitions count /sbin/fdisk)
# first need device name from df output for eg /boot
$fEol = "<BR>\n";
$bTable = "<table border=\"1\" width=\"640\">";
$eTable = "</table><BR>\n";
$bTitle = "<th colspan=\"5\" bgcolor=\"#CCCCCC\">";
$eTitle = "</th>\n";
$fHead = "<p align=center><font size=\"3\"><U><B>";
$bBold = "<B>" ;
$eBold = "</B>";
$bTR = "<tr>";
$eTR = "</tr>";
$bTD = "<td bgcolor=\"#FFFFFF\">";
$bTDgr = "<td bgcolor=\"#CCCCCC\">";
$eTD = "</td>";
$fPar = "<P></P>\n";
$bFail = "<B><font color=FF0000>";
$eFail = "</font></B>\n";
$fPass = "<B><font color=06633>";
$headline = "$bTR$bTDgr Description $eTD$bTDgr Expected Results $eTD$bTDgr Actual Result $eTD$bTDgr Status $eTD$eTR";

$Title = "Linux RHEL7 Qualification Verification Log";

$server_result = 2;    # 0 = Failed; 1 = Warnings; 2 = Passed
$component_result = 2; # 0 = Failed; 1 = Warnings; 2 = Passed
$component_count = 0;

sub server_head {
  ##############
  # gather General Info
  print OUTPUT $bTable;
  print OUTPUT $bTitle,$Title,$eTitle;
  $host = `hostname -f`;
  $date = `date`;
  $me =  `whoami`;
  print OUTPUT $bTR, $bTD;
  print OUTPUT $bBold, "Computer name - ", $eBold, $host, $fEol;
  print OUTPUT $bBold, "Executed by - ", $eBold, $me, $fEol;
  print OUTPUT $bBold, "Script Started (Log Creation Date) - ", $eBold, $date, $fEol;
  print OUTPUT $bBold, "Log File Name - ", $eBold, $LOGFILE, $fEol;
  print OUTPUT $bBold, "Script Name - ", $eBold, "GAB-RHEL7-IQS.sh", $fEol;
  print OUTPUT $bBold, "Script Version - ", $eBold, $VERSION, $fEol;
  print OUTPUT $bBold, "Script Last Modification Date - ", $eBold, $LAST_MOD_DATE, $fEol;
  print OUTPUT $eTD, $eTR;
  print OUTPUT $eTable;
  $server_result = 1;
}

sub server_result {
  print RESULT $bTable;
  print RESULT $bTR,$bTitle,"Qualification Result",$eTitle,$eTR;
}

sub server_summ {
  print SUMM $bTable;
  print SUMM $bTR,$bTitle,"Summary Result",$eTitle,$eTR;
}

sub server_tail {
  print OUTPUT $bTable;
  print OUTPUT $bTR, $bTD;
  print RESULT $bTR, $bTitle;
  print SUMM $bTR, $bTitle;
  print OUTPUT "<p align=center>";
  if ($server_result == 1) {
    print OUTPUT "<B><font size=\"5\" color=\"#009933\">SERVER INSTALLATION QUALIFICATION SUCCESSFUL</font></B>";
    print RESULT "<font color=\"#009933\">Server Installation Qualification SUCCESSFUL</font>";
    print SUMM "<font color=\"#009933\">Server Installation Qualification SUCCESSFUL</font>";
    print "Server Installation Qualification SUCCESSFUL\n";
  } elsif ($server_result == 1) {
    print OUTPUT "<B><font size=\"5\" color=\"#F88033\">SERVER INSTALLATION QUALIFICATION SUCCESSFUL WITH WARNING</font></B>";
    print RESULT "<font color=\"#F88033\">Server Installation Qualification SUCCESSFUL WITH WARNINGS</font>";
    print SUMM "<font color=\"#F88033\">Server Installation Qualification SUCCESSFUL WITH WARNINGS</font>";
    print "Server Installation Qualification SUCCESSFUL WITH WARNINGS\n";
  } else {
    print OUTPUT "<B><font size=\"5\" color=\"#FF0033\">SERVER INSTALLATION QUALIFICATION FAILED</font></B>";
    print RESULT "<font color=\"#FF0033\">Server Installation Qualification FAILED</font>";
    print SUMM "<font color=\"#FF0033\">Server Installation Qualification FAILED</font>";
    print "Server Installation Qualification FAILED\n";
  }
  print OUTPUT "</p>";
  print OUTPUT $eTD, $eTR;
  print RESULT $eTitle, $eTR;
  print SUMM $eTitle, $eTR;
  print OUTPUT $eTable, $fEol;
  print RESULT $eTable, $fEol;
  print SUMM $eTable, $fEol;
}

sub trim {
  my $s = shift;
  $s =~ s/^\s+|\s+$//g;
  return $s
}

sub component_head {
  my ($title) = @_;
  $component_count++;
  printf "%2d - $title\n", $component_count;
  print OUTPUT $bTable;
  print OUTPUT $bTitle,"<A name='Comp$component_count'>$title</A>",$eTitle;
  print OUTPUT $headline, $fEol;
  print SUMM "$bTR$bTD<A href='#Comp$component_count'>$title</A>$eTD";
  $component_result = 2;
}

sub compare_versions {
  my ($exp, $act) = @_;
  $vexp=(version->parse($exp));
  $vact=(version->parse($act));
  return "greater" if $vact > $vexp;
  return "less" if $vact < $vexp;
  return "equal" if $vact = $vexp;
}

sub component_line {
  my ($name, $exp, $act, $result) = @_;
  $col = "";
  $col = "<font color=\"#FF0033\">" if ($result != 1);
  print OUTPUT "$bTR";
  print OUTPUT "$bTD$col$name$eTD";
  print OUTPUT "$bTD$col$exp$eTD";
  print OUTPUT "$bTD$col$act$eTD";
  if ($result == 1) {
    print OUTPUT "$bTD Passed$eTD";
  } else {
    print "     Failed - $name - $exp - $act\n";
    print OUTPUT "$bTD$col Failed$eTD";
    $component_result = 0;
  }
  print OUTPUT "$eTR\n";
}

sub component_line_subhead {
  my ($title) = @_;
  $col = "";
  print OUTPUT "$bTR";
  print OUTPUT "<td colspan=\"5\"> $title </td>";
  print OUTPUT "$eTR\n";
}

sub component_line_warn {
  my ($name, $exp, $act, $result) = @_;
  $col = "";
  $col = "<font color=\"#F88033\">" if ($result != 1);
  print OUTPUT "$bTR";
  print OUTPUT "$bTD$col$name$eTD";
  print OUTPUT "$bTD$col$exp$eTD";
  print OUTPUT "$bTD$col$act$eTD";
  if ($result == 1) {
    print OUTPUT "$bTD Passed$eTD";
  } else {
    print "     Warning - $name - $exp - $act\n";
    print OUTPUT "$bTD$col Warning$eTD";
    $component_result = 1 if ($component_result == 2);
  }
  print OUTPUT "$eTR\n";
}

sub component_line_strlist {
  my ($name, $exp, $act) = @_;
  for ($v = 0; $v < scalar @{$exp}; $v++) {
    if ($act eq @{$exp}[$v]) { last; }
  }
  if ($v eq scalar @{$exp}) {
    component_line($name, join('<BR><EM>or</EM><BR>', @{$exp}), $act, 0);
    return "";
  } else {
    component_line($name, join('<BR><EM>or</EM><BR>', @{$exp}), $act, @{$exp}[$v] eq $act);
    return @{$exp}[$v];
  }
}

sub component_line_str {
  my ($name, $exp, $act) = @_;
  component_line($name, $exp, $act, $exp eq $act);
}

sub component_line_warn_str {
  my ($name, $exp, $act) = @_;
  component_line_warn($name, $exp, $act, $exp eq $act);
}

sub component_line_lcstr {
  my ($name, $exp, $act) = @_;
  component_line($name, $exp, $act, lc($exp) eq lc($act));
}

sub component_line_num {
  my ($name, $exp, $act, $oper) = @_;
  if ($oper eq ">=") {
    $extra="less or equal than";
  } elsif ($oper eq ">") {
    $extra="less than";
  } elsif ($oper eq "<=") {
    $extra="greater or equal than";
  } elsif ($oper eq "<") {
    $extra="greater than";
  } else {
    $extra="";
  }
  component_line($name, $extra." ".$exp, $act, eval("$exp $oper $act"));
}

sub component_line_ver_num {
  my ($name, $exp, $act, $oper) = @_;
  if ($oper eq "<=") {
    $extra="less or equal than";
  } elsif ($oper eq "<") {
    $extra="less than";
  } elsif ($oper eq ">=") {
    $extra="greater or equal than";
  } elsif ($oper eq ">") {
    $extra="greater than";
  } elsif ($oper eq "==") {
    $extra="equals";
  } else {
    $extra="";
  }
  if ($extra =~ compare_versions($exp, $act)) {
    $pkgtest=1;
  } else {
    $pkgtest=0;
  }
  component_line($name, $extra." ".$exp, $act, $pkgtest);

}

sub component_tail {
  print OUTPUT $bTitle, "Component Installation Result: ";
  if ($component_result == 2) {
    print "     -> Passed\n";
    print OUTPUT "<font color=\"#009933\">Passed";
    print SUMM "$bTD<font color=\"#009933\">Passed$eTD$eTR\n";
  } elsif ($component_result == 1) {
    print "     -> Warnings\n";
    print OUTPUT "<font color=\"#F88033\">Warnings";
    print SUMM "$bTD<font color=\"#F88033\">Warnings$eTD$eTR\n";
    $server_result = 1 if ($server_result == 2);
  } else {
    print "     -> Failed\n";
    print OUTPUT "<font color=\"#FF0033\">Failed";
    print SUMM "$bTD<font color=\"#FF0033\">Failed$eTD$eTR\n";
    $server_result = 0;
  }
  print OUTPUT $eTitle;
  print OUTPUT $eTable;
}

sub check_module {
  my ($name) = @_;
  $count_in_lsmod=`lsmod | grep ^$name | wc -l`;
  chop $count_in_lsmod;
  if ($count_in_lsmod == 0) {
    return "Not Loaded";
  } else {
    return "Loaded";
  }
}

sub check_service_running {
  my ($name) = @_;
  $svc_status = `/usr/bin/systemctl is-active $name  2>&1`;
  if (($?>>8) == 0) {
    return "OK";
  } else {
    return "inactive";
  }
}

sub check_service_enabled {
  my ($name) = @_;
  $svc_status = `/usr/bin/systemctl is-enabled $name  2>&1`;
  if (($?>>8) == 0) {
    return 1;
  } else {
    return 0;
  }
}

sub check_service_unused {
  my ($name) = @_;
  $svc_status = `/usr/bin/systemctl is-active $name`;
  if (($?>>8) == 3) {
    return "unused";
  } else {
    return "Not OK";
  }
}

sub check_package {
  my ($name) = @_;
  $svc_status = `rpm -q $name`;
  if (($?>>8) == 0) {
    return 1;
  } else {
    return 0;
  }
}

sub check_rpmpkg_version {
  my ($name, $exppkgver, $oper) = @_;
  if ($oper eq ">=") {
    $extra="greater or equal than";
  } elsif ($oper eq ">") {
    $extra="greater than";
  } elsif ($oper eq "<=") {
    $extra="less or equal than";
  } elsif ($oper eq "<") {
    $extra="less than";
  } else {
    $extra="";
  }
  $actpkgver=`rpm -q $name --qf %{VERSION}`;
  if (($?>>8) != 0) {
    $actpkgver="0.0.0";
  }
  if ($actpkgver eq "package $name is not installed") {
    component_line($name, $extra." ".$exppkgver, "Not Installed", "0");
  } else {
    if ($extra =~ compare_versions($exppkgver, $actpkgver)) {
      $pkgtest=1;
    } else {
      $pkgtest=0;
    }
    component_line($name, $extra." ".$exppkgver, $actpkgver, $pkgtest);
  }
}

sub check_version {
  my ($name, $exppkgver, $oper) = @_;
  if ($oper eq ">=") {
    $extra="greater or equal than";
  } elsif ($oper eq ">") {
    $extra="greater than";
  } elsif ($oper eq "<=") {
    $extra="less or equal than";
  } elsif ($oper eq "<") {
    $extra="less than";
  } else {
    $extra="";
  }

  $actpkgver=` $name -v`;
  chop $actpkgver;
  if ($extra =~ compare_versions($exppkgver, $actpkgver)) {
    $pkgtest=1;
  } else {
    $pkgtest=0;
  }
  component_line($name, $extra." ".$exppkgver, $actpkgver, $pkgtest);
}

sub check_listening {
  my ($port) = @_;
  $togrep="-e \"0.0.0.0:$port \" -e \":::$port \"";
  @server_ips=@{$serverinfo{'ips'}};
  for $i (0..$#server_ips) {
    ($ips[$i], $cidrs[$i]) = split(/\//, $server_ips[$i]);
    $togrep="$togrep -e \"$ips[$i]:$port \"";
  }
  $lsnr_status = `netstat -an | grep $togrep| wc -l`;
  chop $lsnr_status;
  if ($lsnr_status == 0 ) {
    return "Not OK";
  } else {
    return "OK";
  }
}

sub check_process {
  my ($process) = @_;
  $ps_status = `ps -ef | grep $process | grep -v grep | wc -l`;
  chop $ps_status;
  if ($ps_status >= 1 ) {
    return "OK";
  } else {
    return "Not OK";
  }
}

sub check_sysctl {
  my ($key) = @_;
  $sc_key = `sysctl $key`;
  chomp $sc_key;
  ($p, $v) = split(/\s*=\s*/, $sc_key);
  return "$v";
}

sub check_sysctl_conf {
  my ($key, $value) = @_;
  my $retval = 0;
  $sc_num = `grep -c "\\W*$key\\W*=" /etc/sysctl.conf`;
  chomp $sc_num;
  if($sc_num != 0) {
    $sc_key = `grep "\\W*$key\\W*=" /etc/sysctl.conf`;
    chomp $sc_key;
    ($p, $v) = split(/\s*=\s*/, $sc_key);
    $tv = trim($v);
	if( $tv == $value) {
	  $retval = 1
	}
  }
  return $retval;
}

sub check_sshd_conf {
  my ($key, $value) = @_;
  my $retval = 0;
  $sshd_num = `grep -c "^$key " /etc/ssh/sshd_config`;
  if($sshd_num != 0) {
    $sshd_key = `grep "^$key " /etc/ssh/sshd_config`;
    chomp $sshd_key;
    if ($sshd_key =~ ".") {
    ($p, $v) = split(/\s+/, $sshd_key);
    if( $v = $value){
	  $retval = 1;
	}
  }
  }
  return $retval;
}

sub check_postfixparam {
  my ($param) = @_;
  $pf_val = `postconf $param`;
  chomp $pf_val;
  ($p, $v) = split(/\s*=\s*/, $pf_val);
  return "$v";
}

sub check_host_conf {
  my ($key) = @_;
  $host_num = `grep -c "^$key " /etc/host.conf`;
  if($host_num == 0) {
    return "missing";
  } elsif($host_num > 1) {
    return "key occurs $host_num times";
  }
  $host_key = `grep "^$key " /etc/host.conf`;
  chomp $host_key;
  if ($host_key =~ ".") {
    ($p, $v) = split(/\s+/, $host_key);
    return "$v";
  }
}

sub check_startup_xinetd {
  my ($name) = @_;
  $svc_startup = `/sbin/chkconfig --list $name | tail -1`;
  ($svc, @d) = split(/\s+/, $svc_startup, -1);
  #print "$svc - $d[0] - $d[1]\n";
  if      ($d[1] eq "on") {
    return "Automatic";
  } elsif ($d[0] eq "off") {
    return "Disabled";
  } else {
    return "Error";
  }
}

sub check_hostsallow {
  my ($key) = @_;
  my $hosts_allow = "/etc/hosts.allow";
  my $retval = 0;
  my $line127nw = $line10nw = $line172nw = 0;
  open(HOSTS_ALLOW, $hosts_allow) || print "Could not open $hosts_allow \n";
  while(<HOSTS_ALLOW>) {
    chop;
	s/#.*//;
	next if /^\s*$/;
	if($_ =~ "ALL: 127.0"){
	  $line127nw = 1;
	}elsif($_ =~ "ALL: 10."){
	  $line10nw = 1;
	}elsif($_ =~ "ALL: 172."){
	  $line172nw = 1;
	}
  }
  if($line127nw && $line10nw && $line172nw){
    $retval = 1;
  }
  close(HOSTS_ALLOW);
  return $retval;
}

sub check_hostsdeny {
  my ($key) = @_;
  my $hosts_deny = "/etc/hosts.deny";
  my $retval = 0;
  open(HOSTS_DENY, $hosts_deny) || print "Could not open $hosts_deny \n";
  while(<HOSTS_DENY>) {
    chop;
	s/#.*//;
	next if /^\s*$/;
	if($_ =~ "ALL: ALL") {
	  $retval = 1 ;
	}
  }
  close(HOSTS_DENY);
  return $retval;
}

sub check_jnj_sec_conf {
  $cis_conf = "/etc/modprobe.d/jnj_security.conf";
  my ($key) = @_;
  my $retval = 0;
  open(CISCONF, $cis_conf) || print "Can not open $cis_conf\n";
  while (<CISCONF>) {
    my($str1,$fs,$status) = split;
	if ($fs eq $key) {
	  $retval = 1; 
      last;	  
	}
  }
close(CISCONF);
  return $retval;
}

sub check_if_mount_point {
  my ($key) = @_;
  $mountpoint =`/usr/bin/mountpoint $key`;
  chomp $mountpoint;
  if("$mountpoint" eq "$key is a mountpoint") {
    return 1;  
  } else {
    return 0;
  }
  
}

sub check_audit_rules {
  my ($key) = @_;
  my $retval = 0;
  $rulecount = `grep -c "$key" /etc/audit/audit.rules`;
  if ( $rulecount > 0) {
    $retval = 1;
  }
  return $retval;
}

sub check_limits_conf {
   my $retval = 0;
   my ($key) = @_;
   my $corelimits=`grep -c "$key" /etc/security/limits.conf`;
   chomp $corelimits;
   if ( $corelimits != 0 ) {
     $retval = 1;
   }

   return $retval;
}

sub check_fstab_entry {
  my $fstab_file = "/etc/fstab";
  my ($field,$dir,$key) = @_;
  my $retval = 0;
  open(FSTAB, $fstab_file) || print "Can Not open $fstab_file:$!\n";
  while (<FSTAB>) {
    s/#.*//;
    next if /^\s*$/;
	my($device,$mount_point,$type,$options,$dump,$pass) = split;
	my @opts = split /,/, $options;
  if ( $field eq "mountpoint") {
	if( $mount_point eq $key) {
	  $retval = 1;
	  last;
	}
   }
  if( $field eq "options") {
    if ( $mount_point eq $dir) { 
	  foreach $var (@opts) {
	    if ($var eq $key){
		  $retval = 1;
		  last;
		}
	  }
	}
  }
		
  }
 close(FSTAB);
 return $retval;
}

sub check_file_contents {
  my ($file, $search) = @_;
  open my $fh, '<', $file or print "could not open $file : $!";
  while (<$fh>) {
    return 1 if /$search/;
  }
  return;
}

open(SERVERINFO, "</etc/jnj-install/config") or print "Cannot open /etc/jnj-install/config\n";

while (<SERVERINFO>) {
  chop;
  ($data, $comment) = split(/\s*\#/);
  ($name, $value) = split(/=/, $data);
  next if $name eq "";
  $serverinfo{$name} = [ split(/,/, $value) ];
  print "$name -> @{$serverinfo{$name}}\n";
}
close(SERVERINFO);

$platform=`uname -i`;
chop $platform;
##############
# Start report
open(OUTPUT,">$LOGFILE");
open(SUMM,">$LOGFILE.summ");
open(RESULT,">$LOGFILE.result");
#@text = <report>;

print OUTPUT "<HTML>\n";
server_head();
print OUTPUT "<!--ADD_RESULT-->\n";
print OUTPUT "<!--ADD_SUMMARY-->\n";
server_result();
server_summ();

# Section1
$REQSZ=1900;
@parts = `df -mP /home /var /tmp /var/log /var/log/audit`;
chomp @parts;
$homesize = $varsize = $tmpsize = $varlogsize = $varauditsize = 0;
$homelv = $varlv = $tmplv = $varloglv = $varauditlv = "Not_found";
foreach (@parts)
{
   $mount = $mblocks ="";
   ($dev,$mblocks,$used,$avail,$pctused,$mount) = split;
  if ( $mount eq "/home") {
     $homesize = $mblocks;
	 $homlv =`lvs --noheadings -o lv_name $dev`;
	} elsif ( $mount eq "/var") {
     $varsize = $mblocks;
	 $varlv =`lvs --noheadings -o lv_name $dev`;
	} elsif ( $mount eq "/tmp") {
     $tmpsize = $mblocks;
	 $tmplv =`lvs --noheadings -o lv_name $dev`;
	
    } elsif ( $mount eq "/var/log") {
     $varlogsize = $mblocks;
	 $varloglv =`lvs --noheadings -o lv_name $dev`;
	} elsif ( $mount eq "/var/log/audit") {
     $varauditsize = $mblocks;
	 $varauditlv =`lvs --noheadings -o lv_name $dev`;
	}
}
@lv_list = ($homlv,$varlv,$tmplv,$varloglv,$varauditlv);
chop @lv_list;
foreach $lv (@lv_list){
   $lv = trim($lv);
}
component_head("1 Install Updates, Patches and Additional Security Software");
component_line_subhead("1.1 Filesystem Configuration");

if ( (check_if_mount_point("/tmp")) && (check_fstab_entry("mountpoint","/tmp","/tmp")) && ($tmpsize > $REQSZ) ) {
 component_line("1.1.1 Create Separate Partition for /tmp ","lv_tmp logical volume in vg00 volume group, Size >= 2GB","lv_tmp logical volume in vg00 volume group, Size >= 2GB",1);
} else {
  component_line("1.1.1 Create Separate Partition for /tmp ","lv_tmp logical volume in vg00 volume group, Size >= 2GB","$tmplv logical volume in $tmpvg volume group, Size: $tmpsize",0);
}


$nodevstr = (check_fstab_entry("options","/tmp","nodev")) ? "/tmp entry in /etc/fstab has nodev option set in forth field" : "nodev not found in fstab";
component_line_str("1.1.2 Set nodev option for /tmp Partition","/tmp entry in /etc/fstab has nodev option set in forth field", $nodevstr);

$nosuidstr = (check_fstab_entry("options","/tmp","nosuid")) ? "/tmp entry in /etc/fstab has nosudi option set in forth field" : "nosuid not found in fstab";
component_line_str("1.1.3 Set nosuid option for /tmp Partition","/tmp entry in /etc/fstab has nosudi option set in forth field", $nosuidstr);

$noexecstr = (check_fstab_entry("options","/tmp","noexec")) ? "/tmp entry in /etc/fstab has noexec option set in fourth field " : "noexec not found in fstab";
component_line_str("1.1.4 Set noexec option for /tmp Partition","noexec not found in fstab", $noexecstr);


if( (check_if_mount_point("/var")) && (check_fstab_entry("mountpoint","/var","/var")) && ($varsize > $REQSZ) ){
  component_line("1.1.5 Create Separate Partition for /var","lv_var logical volume in vg00 volume group, Size >= 2GB", "lv_var logical volume in vg00 volume group, Size >= 2GB",1);
}else {
  component_line("1.1.5 Create Separate Partition for /var","lv_var logical volume in vg00 volume group, Size >= 2GB", "$varlv logical volume in vg00 volume group, Size $varsize",0);
}


$vartmpstr = (check_fstab_entry("options","/var/tmp","bind")) ? "/etc/fstab file contains /tmp /var/tmp none bind 0 0" : "fstab entry not found";
component_line_str("1.1.6 Bind Mount the /var/tmp directory to /tmp","/etc/fstab file contains /tmp /var/tmp none bind 0 0", $vartmpstr);


if( (check_if_mount_point("/var/log")) && (check_fstab_entry("mountpoint","/var/log","/var/log")) && ($varlogsize > $REQSZ) ){
  component_line("1.1.7 Create Separate Partition for /var/log","lv_varlog logical volume in vg00 volume group, Size >= 2GB", "lv_varlog logical volume in vg00 volume group, Size >= 2GB",1);
}else {
  component_line("1.1.7 Create Separate Partition for /var/log","lv_varlog logical volume in vg00 volume group, Size >= 2GB", "$varloglv logical volume in vg00 volume group, Size : $varlogsize",0);
}

if( (check_if_mount_point("/var/log/audit")) && (check_fstab_entry("mountpoint","/var/log/audit","/var/log/audit")) && ($varauditsize > $REQSZ) ){
  component_line("1.1.8 Create Separate Partition for /var/log/audit","lv_varlog logical volume in vg00 volume group, Size >= 2GB", "lv_varlog logical volume in vg00 volume group, Size >= 2GB",1);
}else{
  component_line("1.1.8 Create Separate Partition for /var/log/audit","lv_varlog logical volume in vg00 volume group, Size >= 2GB", "$varauditlv logical volume in vg00 volume group, Size : $varauditsize",0);
}

if( (check_if_mount_point("/home")) && (check_fstab_entry("mountpoint","/home","/home")) && ($homesize > $REQSZ)){
  component_line("1.1.9 Create Separate Partition for /home","lv_varlogaudit logical volume in vg00 volume group, Size >= 2GB", "lv_varlogaudit logical volume in vg00 volume group, Size >= 2GB",1);
} else{
  component_line("1.1.9 Create Separate Partition for /home","lv_varlogaudit logical volume in vg00 volume group, Size >= 2GB", "$varauditlv logical volume in vg00 volume group, Size : $homesize",0);
}

$homenodevstr = (check_fstab_entry("options","/home","nodev")) ? "/home entry in /etc/fstab has nodev option set in forth field" : "nodev not found in fstab";
component_line_str("1.1.10 Add nodev option to /home","/home entry in /etc/fstab has nodev option set in forth field", $homenodevstr);

$NAmediastr = "GTS does not configure persistent removable media partitions this setting will not be checked.";
component_line_str("1.1.11 Add nodev Option to Removable Media Partitions",$NAmediastr,$NAmediastr);
component_line_str("1.1.12 Add noexec Option to Removable Media Partitions",$NAmediastr,$NAmediastr);
component_line_str("1.1.13 Add nosuid Option to Removable Media Partitions",$NAmediastr,$NAmediastr);

$shmnodev = (check_fstab_entry("options","/dev/shm","nodev")) ? "/dev/shm entry in /etc/fstab has nodev option set in forth field" : "nodev not found in fstab";
component_line_str("1.1.14 Add nodev Option to /dev/shm","/dev/shm entry in /etc/fstab has nodev option set in forth field", $shmnodev);

$shmnosuid = (check_fstab_entry("options","/dev/shm","nosuid")) ? "/dev/shm entry in /etc/fstab has nosuid option set in forth field" : "nosuid not found in fstab";
component_line_str("1.1.15 Set nosuid for /dev/shm","/dev/shm entry in /etc/fstab has nosuid option set in forth field", $shmnosuid);

$shmnoexec = (check_fstab_entry("options","/dev/shm","noexec")) ? "/dev/shm entry in /etc/fstab has noexec option set in forth field" : "noexec not found in fstab";
component_line_str("1.1.16 Add noexec Option to /dev/shm Partition","/dev/shm entry in /etc/fstab has noexec option set in forth field", $shmnoexec);

$wwdirstr="No.of World-Writable dirs : 0";
#$cmd="df --local -P | awk {'if (NR!=1) print \$6'} | xargs -I '{}' find '{}' -xdev -type d \\( -perm -0002 -a ! -perm -1000 \\)";
$cmd="echo";
@wwdirs=`$cmd`;
if ($#wwdis > 0){
  $wwdirstr = "No.of World-Writable dirs : $#wwdirs";
}
component_line_str("1.1.17 Set Sticky Bit on All World-Writable Directories","No.of World-Writable dirs : 0", $wwdirstr);

%disabled_fs = ("cramfs","Not Disabled","freevxfs","Not Disabled", "jffs2","Not Disabled","hfs","Not Disabled","hfsplus","Not Disabled","squashfs","Not Disabled","udf","Not Disabled",);
foreach $fs (keys %disabled_fs) {
  $disabled_fs{"$fs"}=(check_jnj_sec_conf("$fs")) ? "File /etc/modprobe.d/CIS.conf contains install $fs /bin/true" : "$fs not disabled";
}

component_line_str("1.1.18 Disable Mounting of cramfs Filesystems","File /etc/modprobe.d/CIS.conf contains install cramfs /bin/true", $disabled_fs{"cramfs"});
component_line_str("1.1.19 Disable Mounting of freevxfs Filesystems","File /etc/modprobe.d/CIS.conf contains install freevxfs /bin/true", $disabled_fs{"freevxfs"});
component_line_str("1.1.20 Disable Mounting of jffs2 Filesystems","File /etc/modprobe.d/CIS.conf contains install jffs2 /bin/true", $disabled_fs{"jffs2"});
component_line_str("1.1.21 Disable Mounting of hfs Filesystems","File /etc/modprobe.d/CIS.conf contains install hfs /bin/true", $disabled_fs{"hfs"});
component_line_str("1.1.22 Disable Mounting of hfsplus Filesystems","File /etc/modprobe.d/CIS.conf contains install hfsplus /bin/true", $disabled_fs{"hfsplus"});
component_line_str("1.1.23 Disable Mounting of squashfs Filesystems","File /etc/modprobe.d/CIS.conf contains install squashfs /bin/true", $disabled_fs{"squashfs"});
component_line_str("1.1.24 Disable Mounting of udf Filesystems","File /etc/modprobe.d/CIS.conf contains install udf /bin/true", $disabled_fs{"udf"});

component_line_subhead("1.2 Software Updates Configuration");

# rhsatserver check could be a false one, as systemid was removed from all servers by Chef, however, the /etc/jnj-install/config
# file was not updated
component_line_str("1.2.1 JNJ-rhel-x86_64-server-7-20171018.repo exists", "Yes", (-f "/etc/yum.repos.d/JNJ-rhel-x86_64-server-7-20171018.repo")? "Yes" : "No");

#if ($serverinfo{'rhsatserver'}[0] eq "N/A") {
#  component_line_str("/etc/yum.repos.d/JNJ-rhel-x86_64-server-7-20171018.repo exists", "Yes", (-f "/etc/yum.repos.d/JNJ-rhel-x86_64-server-7-20171018.repo")? "Yes" : "No");
#} else {
#$channel = `rhn-channel -b`;
#chop $channel;
#component_line_str("1.2.1 Configure Connection to the RHN RPM Repositories", "JNJ-rhel-x86_64-server-7.4", $channel);

$gpgkeystr = (check_package("gpg-pubkey")) ? "GPG Key is Installed" : "GPG Key Not Installed";
component_line_str("1.2.2 Verify Red Hat GPG Key is Installed","GPG Key is Installed", $gpgkeystr);
#}
$yum_config = "/etc/yum.conf";
$gpg_globalstr = "Not enabled";
open(YUMCONF,$yum_config) or print "Could not open $yum_config \n";
while(<YUMCONF>) {
  s/#.*//;
  next if /^\s*$/;
  my ($key,$value) = split /=/;
  if ($key eq "gpgcheck" && $value == 1) {
    $gpg_globalstr = "File /etc/yum.conf contains gpgcheck=1";
  }
}
component_line_str("1.2.3 Verify that gpgcheck is Globally Activated","File /etc/yum.conf contains gpgcheck=1", $gpg_globalstr);

$rhnsdstr = (check_service_enabled("rhnsd")) ? "rhnsd daemon enabled" : "rhnsd daemon disbled";
component_line_str("1.2.4 Disable the rhnsd Daemon","rhnsd daemon enabled", $rhnsdstr);

$yumstr="Not-up-to-date";
$yumupdate=`yum check-update`;
if( $? >> 8 == 0 ){
  $yumstr = "up-to-date"
}
component_line_str("1.2.5 Obtain Software Package Updates with yum","up-to-date",$yumstr);


component_line_str("1.2.6 Verify Package Integrity Using RPM","N/A","N/A");

$aidestr = (check_package("aide")) ? "AIDE Installed" : "AIDE Not Installed";
component_line_str("1.3 Advanced Intrusion Detection Environment (AIDE)","AIDE Not Installed", $aidestr);

$SELinux=`/usr/sbin/sestatus`;
($SELinux_status) = (split(/ /,$SELinux))[-1];
chop $SELinux_status;
component_line_str("1.4 SELinux Configuration","disabled", $SELinux_status);

component_line_subhead("1.5 Secure Boot Settings");

$grub2_ownership=`stat -L -c "Ownership : %U:%G" /boot/grub2/grub.cfg`;
chomp $grub2_ownership;
component_line_str("1.5.1 Set User/Group Owner on /boot/grub2/grub.cfg","Ownership : root:root", $grub2_ownership);

$grub2_perm=`stat -L -c "Permissions : %a" /boot/grub2/grub.cfg`;
chomp $grub2_perm;
component_line_str("1.5.2 Set Permissions on /boot/grub2/grub.cfg","Permissions : 600", $grub2_perm);


$str153 = `grep -c "^set superusers" /boot/grub2/grub.cfg`;
if ($str153 == 0){
 $grubpass = "Not configured"
}
component_line_str("1.5.3 Set Boot Loader Password","Not configured", $grubpass);

component_line_subhead("1.6 Additional Process Hardening");

$coredumpstr = "Not configured";
$core_limits = (check_limits_conf("hard core 0")) ? "core dump ZERO updated in limits.conf" : "Not found in limits.conf";
$core_sysctl = (check_sysctl_conf("fs.suid_dumpable", "0")) ? " and sysctl.conf" : ",Not found in sysctl.conf";
$coredumpstr = $core_limits . $core_sysctl;
component_line_str("1.6.1 Restrict Core Dumps","core dump ZERO updated in limits.conf and sysctl.conf", $coredumpstr);

$vmemstr = (check_sysctl_conf("kernel.randomize_va_space", "2")) ? "sysctl.conf updated with randomize_va_space" : ",Not found in sysctl.conf";
component_line_str("1.6.2 Enable Randomized Virtual Memory Region Placement","sysctl.conf updated with randomize_va_space", $vmemstr);

$osversion=`cat /etc/redhat-release`;
chomp $osversion;
component_line_str("1.7 Use Latest OS Release","Red Hat Enterprise Linux Server release 7.4 (Maipo)", $osversion);

component_tail();
#################

#Section2
component_head("2 OS Services");
component_line_subhead("2.1 Remove Legacy Services");
# GTSC has telnet installed (easier to debug network services)
%legacy_rpm = ("telnet-server", "Installed","telnet","Installed","rsh-server","Installed","rsh","Installed","ypbind","Installed","ypserv","Installed","tftp","Installed","tftp-server","Installed","talk","Installed","talk-server","Installed","xinetd","Installed",);
foreach $lrpm (keys %legacy_rpm){
  $legacy_rpm{"$lrpm"} =(check_package("$lrpm") ? "$lrpm installed" : "$lrpm is not present");
}

component_line_str("2.1.1 Remove telnet-server ","telnet-server is not present", $legacy_rpm{"telnet-server"});
component_line_str("2.1.2 Remove telnet Clients","telnet is not present", $legacy_rpm{"telnet"});
#component_line_str("2.1.2 Telnet Client","telnet installed", $legacy_rpm{"telnet"});
component_line_str("2.1.3 Remove rsh-server","rsh-server is not present", $legacy_rpm{"rsh-server"});
component_line_str("2.1.4 Remove rsh","rsh is not present", $legacy_rpm{"rsh"});
component_line_str("2.1.5 Remove NIS Client","ypbind is not present", $legacy_rpm{"ypbind"});
component_line_str("2.1.6 Remove NIS Server","ypserv is not present", $legacy_rpm{"ypserv"});
component_line_str("2.1.7 Remove tftp","tftp is not present", $legacy_rpm{"tftp"});
component_line_str("2.1.8 Remove tftp-server ","tftp-server is not present", $legacy_rpm{"tftp-server"});
component_line_str("2.1.9 Remove talk","talk is not present", $legacy_rpm{"talk"});
component_line_str("2.1.10 Remove talk-server","talk-server is not present", $legacy_rpm{"talk-server"});
component_line_str("2.1.11 Remove xinetd","xinetd is not present", $legacy_rpm{"xinetd"});

%legacy_service = ("chargen-dgram","Enabled","chargen-stream","Enabled","daytime-dgram","Enabled","daytime-stream","Enabled","echo-dgram","Enabled","echo-stream","Enabled","tcpmux-server","Enabled",);
foreach $lservice (keys %legacy_service) {
  $legacy_service{"$lservice"} = (check_service_enabled("$lservice")) ? "$lservice service is enabled" : "$lservice service is disabled";
}
component_line_str("2.1.12 Disable chargen-dgram","chargen-dgram service is disabled", $legacy_service{"chargen-dgram"});
component_line_str("2.1.13 Disable chargen-stream","chargen-stream service is disabled", $legacy_service{"chargen-stream"});
component_line_str("2.1.14 Disable daytime-dgram","daytime-dgram service is disabled", $legacy_service{"daytime-dgram"});
component_line_str("2.1.15 Disable daytime-stream","daytime-stream service is disabled", $legacy_service{"daytime-stream"});
component_line_str("2.1.16 Disable echo-dgram","echo-dgram service is disabled", $legacy_service{"echo-dgram"});
component_line_str("2.1.17 Disable echo-stream","echo-stream service is disabled", $legacy_service{"echo-stream"});
component_line_str("2.1.18 Disable tcpmux-server","tcpmux-server service is disabled", $legacy_service{"tcpmux-server"});

component_tail();
################

#section3
component_head("3 Special Purpose Services");

$default_umask=`grep umask /etc/sysconfig/init`;
$umaskstr = "Not set";
chomp $default_umask;
($dmask, $dmaskval) = split(/ /, $default_umask);
if ($dmaskval eq "027"){
 $umaskstr = "deamon umask is set to 027 in /etc/sysconfig/init";
}
component_line_str("3.1 Set Daemon umask","deamon umask is set to 027 in /etc/sysconfig/init", $umaskstr);

%section3_rpm_list=("xorg-x11-server-common","Installed","dhcp","Installed","openldap-server","Installed","openldap-client","Installed","bind","Installed","vsftpd","Installed","dovecot","Installed","samba","Installed","squid","Installed");
foreach $rpm (keys %section3_rpm_list){
  $section3_rpm_list{"$rpm"} = (check_package("$rpm") ? "$rpm installed" : "$rpm rpm is not present");
}

%section3_service_list=("avahi-daemon","Enabled","cups","Enabled");
foreach $service (keys %section3_service_list) {
  $section3_service_list{"$service"} = (check_service_enabled("$service")) ? "$service is enabled" : "$service service is disabled";
}

component_line_str("3.2 Remove the X Window System","SKIPPED", "SKIPPED");
component_line_str("3.3 Disable Avahi Server","avahi-daemon service is disabled", $section3_service_list{"avahi-daemon"});
component_line_str("3.4 Disable Print Server - CUPS","cups service is disabled", $section3_service_list{"cups"});
component_line_str("3.5 Remove DHCP Server","dhcp rpm is not present", $section3_rpm_list{"dhcp"});

$ntp_config = "/etc/ntp.conf";
$ntpcount = 0;
open(NTP_CONF,$ntp_config) || print "Could not open $ntp_config \n";
while (<NTP_CONF>) {
  chop;
  if($_ =~ '^server'){
    $ntpcount++;
  }elsif($_ =~ '^restrict default') {
    $ntpstr2 = ",restrict default";
  }elsif($_ =~ '^logfile */var/log/ntp *#'){
    $ntpstr3 = ",logfile";
  }
}
close(NTP_CONF);

$ntpd_conf = "/etc/sysconfig/ntpd";
open(NTPD_CONF, $ntpd_conf) || print "Could not open $ntpd_conf \n";
while (<NTPD_CONF>) {
  chop;
  ($x,$y) = split /=/;
  if($x eq "OPTIONS" && $y =~ "-u ntp:ntp") {
    $ntpstr4 = ",nptd are configured";
  }
}
close(NTPD_CONF);
$ntpstr1 = $ntpcount . " ntp entries";
$ntpstr = $ntpstr1 . $ntpstr2 . $ntpstr3 . $ntpstr4;
component_line_str("3.6 Configure Network Time Protocol (NTP)","3 ntp entries,restrict default,logfile,nptd are configured", $ntpstr);

component_line_str("3.7 Remove LDAP","openldap-server rpm is not present", $section3_rpm_list{"openldap-server"});
component_line_str("3.8 Disable NFS and RPC","N/A", "N/A");
component_line_str("3.9 Remove DNS Server","bind rpm is not present", $section3_rpm_list{"bind"});
component_line_str("3.10 Remove FTP Server ","vsftpd rpm is not present", $section3_rpm_list{"vsftpd"});

component_line_str("3.11 Remove HTTP Server","N/A", "N/A");
component_line_str("3.12 Remove Dovecot (IMAP and POP3 services)","dovecot rpm is not present", $section3_rpm_list{"dovecot"});
component_line_str("3.13 Remove Samba","samba rpm is not present", $section3_rpm_list{"samba"});
component_line_str("3.14 Remove HTTP Proxy Server","squid rpm is not present", $section3_rpm_list{"squid"});
component_line_str("3.15 Remove SNMP Server","N/A", "N/A");

$mailconf = "/etc/postfix/main.cf";
$mailstr = "Not configured";
open(MAIL,$mailconf) || print "Could not open $mailconf \n";
while(<MAIL>){
  chop;
  s/#.*//;
  next if /^\s*$/;
  ($x,$y) = split /=/;
  if($x =~ "inet_interfaces" && $y =~ "localhost"){
    $mailstr = "/etc/postfix/main.cf file contains GTS standard settings";
	last;
  }
}
component_line_str("3.16 Configure Mail Transfer Agent for Local-Only Mode","/etc/postfix/main.cf file contains GTS standard settings", $mailstr);

component_tail();
#################

#section4
component_head("4 Network Configuration and Firewalls");
component_line_subhead("4.1 Modify Network Parameters");

$str411 = (check_sysctl_conf("net.ipv4.ip_forward", "0")) ? "net.ipv4.ip_forward=0" : "Not Configured";
component_line_str("4.1.1 Disable IP Forwarding","net.ipv4.ip_forward=0", $str411);

$str412 = ((check_sysctl_conf("net.ipv4.conf.all.send_redirects", "0")) && (check_sysctl_conf("net.ipv4.conf.default.send_redirects", "0")) ) ? "/etc/sysctl.conf contains<br>net.ipv4.conf.all.send_redirect=0<br>net.ipv4.conf.default.send_redirects=0" : "Not Configured";
component_line_str("4.1.2 Disable Send Packet Redirects","/etc/sysctl.conf contains<br>net.ipv4.conf.all.send_redirect=0<br>net.ipv4.conf.default.send_redirects=0", $str412);

component_line_subhead("4.2 Modify Network Parameters");

 $str421 = (check_sysctl_conf("net.ipv4.conf.all.accept_source_route","0") && check_sysctl_conf("net.ipv4.conf.default.accept_source_route","0")) ? "/etc/sysctl.conf contains<br>net.ipv4.conf.all.accept_source_root=0<br>net.ipv4.conf.default.accept_source_root=0" : "Not Configured";
component_line_str("4.2.1 Disable Source Routed Packet Acceptance","/etc/sysctl.conf contains<br>net.ipv4.conf.all.accept_source_root=0<br>net.ipv4.conf.default.accept_source_root=0", $str421);

 
$str422 = (check_sysctl_conf("net.ipv4.conf.all.accept_redirects","0") && check_sysctl_conf("net.ipv4.conf.default.accept_redirects","0")) ? "/etc/sysctl.conf contains<br>net.ipv4.conf.all.accept_redirects=0<br>net.ipv4.conf.default.accept_redirects=0" : "Not Configured";
component_line_str("4.2.2 Disable ICMP Redirect Acceptance","/etc/sysctl.conf contains<br>net.ipv4.conf.all.accept_redirects=0<br>net.ipv4.conf.default.accept_redirects=0", $str422);


$str423 = (check_sysctl_conf("net.ipv4.conf.all.secure_redirects","0") && check_sysctl_conf("net.ipv4.conf.default.secure_redirects","0")) ? "/etc/sysctl.conf contains<br>net.ipv4.conf.all.secure_redirects=0<br>net.ipv4.conf.default.secure_redirects=0" : "Not Configured";
component_line_str("4.2.3 Disable Secure ICMP Redirect Acceptance","/etc/sysctl.conf contains<br>net.ipv4.conf.all.secure_redirects=0<br>net.ipv4.conf.default.secure_redirects=0", $str423);

 
$str424 = (check_sysctl_conf("net.ipv4.conf.all.log_martians","1") && check_sysctl_conf("net.ipv4.conf.default.log_martians","1")) ? "/etc/sysctl.conf contains<br>net.ipv4.conf.all.log_martians=1<br>net.ipv4.conf.default.log_martians=1" : "Not Configured";
component_line_str("4.2.4 Log Suspicious Packets","/etc/sysctl.conf contains<br>net.ipv4.conf.all.log_martians=1<br>net.ipv4.conf.default.log_martians=1", $str424);


$str425 = (check_sysctl_conf("net.ipv4.icmp_echo_ignore_broadcasts","1")) ? "/etc/sysctl.conf contains<br>net.ipv4.icmp_echo_ignore_broadcast=1" : "Not Configured";
component_line_str("4.2.5 Enable Ignore Broadcast Requests","/etc/sysctl.conf contains<br>net.ipv4.icmp_echo_ignore_broadcast=1", $str425);

$str426 = (check_sysctl_conf("net.ipv4.icmp_ignore_bogus_error_responses","1")) ? "/etc/sysctl.conf contains<br>net.ipv4.icmp_ignore_bogus_error_responses=1" : "Not Configured";
component_line_str("4.2.6 Enable Bad Error Message Protection","/etc/sysctl.conf contains<br>net.ipv4.icmp_ignore_bogus_error_responses=1", $str426);

$str427 = (check_sysctl_conf("net.ipv4.conf.all.rp_filter","1") && check_sysctl_conf("net.ipv4.conf.default.rp_filter","1"))  ? "/etc/sysctl.conf contains<br>net.ipv4.conf.all.rp_filter=1<br>net.ipv4.conf.default.rp_filter=1" : "Not Configured";
component_line_str("4.2.7 Enable RFC-recommended Source Route Validation","/etc/sysctl.conf contains<br>net.ipv4.conf.all.rp_filter=1<br>net.ipv4.conf.default.rp_filter=1", $str427);


$str428 = (check_sysctl_conf("net.ipv4.tcp_syncookies","1"))  ? "/etc/sysctl.conf contains<br>net.ipv4.tcp_syncookies=1" : "Not Configured";
component_line_str("4.2.8 Enable TCP SYN Cookies","/etc/sysctl.conf contains<br>net.ipv4.tcp_syncookies=1", $str428);

component_line_str("4.3 Wireless Networking","not configured", "not configured");

component_line_subhead("4.4 IPv6");
component_line_subhead("4.4.1 Configure IPv6");

$str4411 = (check_sysctl_conf("net.ipv6.conf.all.accept_ra","0") && check_sysctl_conf("net.ipv6.conf.default.accept_ra","0"))  ? "/etc/sysctl.conf contains<br>net.ipv6.conf.all.accept_ra=0<br>net.ipv6.conf.default.accept_ra=0" : "Not Configured";
component_line_str("4.4.1.1 Disable IPv6 Router Advertisements","/etc/sysctl.conf contains<br>net.ipv6.conf.all.accept_ra=0<br>net.ipv6.conf.default.accept_ra=0", $str4411);


$str4412 = (check_sysctl_conf("net.ipv6.conf.all.accept_redirects","0") && check_sysctl_conf("net.ipv6.conf.default.accept_redirects","0"))  ? "/etc/sysctl.conf contains<br>net.ipv6.conf.all.accept_redirects=0<br>net.ipv6.conf.default.accept_redirects=0" : "Not Configured";
component_line_str("4.4.1.2 Disable IPv6 Redirect Acceptance","/etc/sysctl.conf contains<br>net.ipv6.conf.all.accept_redirects=0<br>net.ipv6.conf.default.accept_redirects=0", $str4412);

$str442 = (check_sysctl_conf("net.ipv6.conf.all.disable_ipv6","1")) ? "Disabled" : "Not found in sysctl.conf";
component_line_str("4.4.2 Disable IPv6","Disabled", $str442);

component_line_subhead("4.5 Install TCP Wrappers");

$tcp_wrp_str = (check_package("tcp_wrappers")) ? "tcp_wrappers rpm Installed" : "tcp_wrappers is not installed";
component_line_str("4.5.1 Install TCP Wrappers","tcp_wrappers rpm Installed", $tcp_wrp_str);

$hosts_allow_str = (check_hostsallow()) ? "/etc/hosts.allow file contains<br>ALL: 127.0.0.1<br>ALL: 10.<br>ALL: 172." : "hosts.allow not properly configured";
component_line_str("4.5.2 Create /etc/hosts.allow","/etc/hosts.allow file contains<br>ALL: 127.0.0.1<br>ALL: 10.<br>ALL: 172.", $hosts_allow_str);

$str453 = "not set";
$hostsallow_perm=`stat -L -c "%a" /etc/hosts.allow`;
chop $hostsallow_perm;
if ($hostsallow_perm == 644){
 $str453 = "/etc/hosts.allow file permissions set to 0644";
}
component_line_str("4.5.3 Verify Permissions on /etc/hosts.allow","/etc/hosts.allow file permissions set to 0644", $str453);

$hosts_deny_str = (check_hostsdeny()) ? "/etc/hosts.deny file contains<br>ALL: ALL" : "hosts.deny not properly configured";
component_line_str("4.5.4 Create /etc/hosts.deny","/etc/hosts.deny file contains<br>ALL: ALL", $hosts_deny_str);

$hostsdeny_perm=`stat -L -c "%a" /etc/hosts.deny`;
chop $hostsdeny_perm;
if($hostsdeny_perm == 644){
  $str455 = "/etc/hosts.deny file permissions set to 0644";
}
component_line_str("4.5.5 Verify Permissions on /etc/hosts.deny","/etc/hosts.deny file permissions set to 0644", $str455);

component_line_subhead("4.6 Uncommon Network Protocols");

%disabled_network_protocols = ("dccp","Not Disabled","sctp","Not Disabled", "rds","Not Disabled","tipc","Not Disabled");
foreach $net (keys %disabled_network_protocols) {
  $disabled_network_protocols{"$net"}=(check_jnj_sec_conf("$net")) ? "/etc/modprobe.d/CIS.conf contains<br>install $net /bin/true" : "$net not disabled";
}
component_line_str("4.6.1 Disable DCCP","/etc/modprobe.d/CIS.conf contains<br>install dccp /bin/true", $disabled_network_protocols{"dccp"});
component_line_str("4.6.2 Disable SCTP","/etc/modprobe.d/CIS.conf contains<br>install sctp /bin/true", $disabled_network_protocols{"sctp"});
component_line_str("4.6.3 Disable RDS","/etc/modprobe.d/CIS.conf contains<br>install rds /bin/true", $disabled_network_protocols{"rds"});
component_line_str("4.6.4 Disable TIPC","/etc/modprobe.d/CIS.conf contains<br>install tipc /bin/true", $disabled_network_protocols{"tipc"});

$str47 = (check_service_enabled("firewalld")) ? "Enabled" : "Disabled";
component_line_str("4.7 Enable firewalld","Disabled", $str47);

component_tail();
#################

#section5
component_head("5 Logging and Auditing");
component_line_subhead("5.1 Configure rsyslog");

$rsyslog_pkg_str = (check_package("rsyslog")) ? "rsyslog rpm present"  : "rsyslog Not Installed";
component_line_str("5.1.1 Install the rsyslog package","rsyslog rpm present", $rsyslog_pkg_str);

$rsyslog_service = (check_service_enabled("rsyslog")) ? "rsyslog service enabled" : "rsyslog not enabled";
component_line_str("5.1.2 Activate the rsyslog Service","rsyslog service enabled", $rsyslog_service);

component_line_str("5.1.3 Configure /etc/rsyslog.conf","/etc/rsyslog.conf contains regional configuration settings for SELM appliance", ( -f "/etc/rsyslog.conf") ? "/etc/rsyslog.conf contains regional configuration settings for SELM appliance" : "Not Configured");

$logfile_permissions = "";
@logfiles = ("/var/log/messages","/var/log/secure","/var/log/cron","/var/log/spooler");
foreach (@logfiles) {
  $perm = `stat -L -c "%a" $_`;
  chop $perm;
  if ( $perm == 600) {
    $logfile_permissions .= "$_ -> Permissions:600<br>"
  }
}
component_line_str("5.1.4 Create and Set Permissions on rsyslog Log Files","/var/log/messages -> Permissions:600<br>/var/log/secure -> Permissions:600<br>/var/log/cron -> Permissions:600<br>/var/log/spooler -> Permissions:600<br>", $logfile_permissions);

$remote_loggin_str = "Not Configured";
$remote_host_count = `grep -v "#" /etc/rsyslog.conf | grep -c ".* @@" /etc/rsyslog.conf`;
chop $remote_host_count;
if ( $remote_host_count > 0 ) {
  $remote_loggin_str = "/etc/rsyslog.conf contains remote loghost setting";
}
component_line_str("5.1.5 Configure rsyslog to Send Logs to a Remote Log Host","/etc/rsyslog.conf contains remote loghost setting", $remote_loggin_str);

$rlog516 = "Not Configured";
$imtcp = `grep -v "#" /etc/rsyslog.conf | grep -c "ModLoad imtcp" /etc/rsyslog.conf`;
$tcprun = `grep -v "#" /etc/rsyslog.conf | grep -c "InputTCPServerRun 514" /etc/rsyslog.conf`;
chomp $imtcp;
chomp $tcprun;
if ( $imtcp > 0 && $tcprun > 0) {
 $rlog516 = "/etc/rsyslog.conf contains<br>ModLoad imtcp.so<br>InputTcpServerRun 514";
}
component_line_str("5.1.6 Accept Remote rsyslog Messages Only on Designated Log Hosts","/etc/rsyslog.conf contains<br>ModLoad imtcp.so<br>InputTcpServerRun 514", $rlog516);

component_line_subhead("5.2 Configure System Accounting");
component_line_subhead("5.2.1 Configure Data Retention");

$auditconf = "/etc/audit/auditd.conf";
$str5211 = $str5212 = $str5213 = "none";
$str5212a = $str5212b = $str5212c = " not present ";
open(AUDIT,$auditconf);
while(<AUDIT>){
  chop;
  s/#.*//;
  next if /^\s*$/;
  ($parm,$value) = split /=/;
  $parm = trim($parm);
  $value = trim($value);
  if ($parm eq "max_log_file" && $value == 6){
    $str5211 = "/etc/audit/auditd.conf contains<br>max_log_file = 6";
  }elsif($parm eq "space_left_action" && $value eq "email"){
    $str5212a = "<br>space_left_action = email";
  }elsif($parm eq "action_mail_acct" && $value eq "root"){
    $str5212b = "<br>action_mail_acct = root";
  }elsif($parm eq "admin_space_left_action" && $value eq "SUSPEND"){
    $str5212c = "<br>admin_space_left_action = SUSPEND"
  }elsif($parm eq "max_log_file_action" && $value eq "keep_logs"){
    $str5213 = "/etc/audit/auditd.conf contains<br>max_log_file_action = keep_logs"
  }
}
close(AUDIT);
$str5212 = "/etc/audit/auditd.conf contains".$str5212a.$str5212b.$str5212c;
component_line_str("5.2.1.1 Configure Audit Log Storage Size","/etc/audit/auditd.conf contains<br>max_log_file = 6", $str5211);
component_line_str("5.2.1.2 Disable System on Audit Log Full","/etc/audit/auditd.conf contains<br>space_left_action = email<br>action_mail_acct = root<br>admin_space_left_action = SUSPEND", $str5212);
component_line_str("5.2.1.3 Keep All Auditing Information","/etc/audit/auditd.conf contains<br>max_log_file_action = keep_logs", $str5213);

$audit_str = (check_service_enabled("auditd") ? "auditd service enabled" : "Not enabled");
component_line_str("5.2.2 Enable auditd Service","auditd service enabled", $audit_str);

$str523 = "not found in /etc/default/grub";
$grubline = `grep -o "audit=1" /etc/default/grub`;
chop $grubline;
if ($grubline eq "audit=1"){
  $str523 = "/etc/default/grub contains<br>audit=1 setting";
}
component_line_str("5.2.3 Enable Auditing for Processes That Start Prior to auditd","/etc/default/grub contains<br>audit=1 setting", $str523);

%AuditRules = ("rule524","time-change",
"rule525", "identity",
"rule526", "system-locale",
"rule527", "MAC-policy",
"rule528", "logins",
"rule529", "session",
"rule5210", "perm_mod",
"rule5211", "access",
"rule5212", "privileged",
"rule5213", "mounts",
"rule5214", "delete",
"rule5215", "scope",
"rule5216", "actions",
"rule5217", "modules",
"rule5218", "-e 2"
);

foreach $RULE (keys %AuditRules) {
  $AuditRules{$RULE} = check_audit_rules("$AuditRules{$RULE}") ? "/etc/audit/audit.rules contains $AuditRules{$RULE} events" : "Not found in /etc/audit/audit.rules";
}

component_line_str("5.2.4 Record Events That Modify Date and Time Information","/etc/audit/audit.rules contains time-change events", $AuditRules{"rule524"});
component_line_str("5.2.5 Record Events That Modify User/Group Information","/etc/audit/audit.rules contains identity events", $AuditRules{"rule525"});
component_line_str("5.2.6 Record Events That Modify the Systems Network Environment","/etc/audit/audit.rules contains system-locale events", $AuditRules{"rule526"});
component_line_str("5.2.7 Record Events That Modify the Systems Mandatory Access","/etc/audit/audit.rules contains MAC-policy events", $AuditRules{"rule527"});
component_line_str("5.2.8 Collect Login and Logout Events ","/etc/audit/audit.rules contains logins events", $AuditRules{"rule528"});
component_line_str("5.2.9 Collect Session Initiation Information","/etc/audit/audit.rules contains session events", $AuditRules{"rule529"});
component_line_str("5.2.10 Collect Discretionary Access Control Permission Modification Events ","/etc/audit/audit.rules contains perm_mod events", $AuditRules{"rule5210"});
component_line_str("5.2.11 Collect Unsuccessful Unauthorized Access Attempts to Files","/etc/audit/audit.rules contains access events", $AuditRules{"rule5211"});
component_line_str("5.2.12 Collect Use of Privileged Commands","/etc/audit/audit.rules contains privileged events", $AuditRules{"rule5212"});
component_line_str("5.2.13 Collect Successful File System Mounts","/etc/audit/audit.rules contains mounts events", $AuditRules{"rule5213"});
component_line_str("5.2.14 Collect File Deletion Events by User","/etc/audit/audit.rules contains delete events", $AuditRules{"rule5214"});
component_line_str("5.2.15 Collect Changes to System Administration Scope","/etc/audit/audit.rules contains scope events", $AuditRules{"rule5215"});
component_line_str("5.2.16  Collect System Administrator Actions (sudolog)","/etc/audit/audit.rules contains actions events", $AuditRules{"rule5216"});
component_line_str("5.2.17 Collect Kernel Module Loading and Unloading","/etc/audit/audit.rules contains modules events", $AuditRules{"rule5217"});
component_line_str("5.2.18 Make the Audit Configuration Immutable","/etc/audit/audit.rules contains -e 2 events", $AuditRules{"rule5218"});


$logrotate_file = "/etc/logrotate.d/syslog";
open(LOGROTATE,$logrotate_file) || print "Could not open $logrotate_file \n";
while(<LOGROTATE>) {
  chop;
  if($_ =~ "/var/log/cron"){
    $log1 = "cron,";
  }elsif($_ =~ "/var/log/messages") {
    $log2 = "messages,";
  }elsif($_ =~ "/var/log/secure"){
    $log3 .= "secure,";
  }elsif($_ =~ "/var/log/maillog"){
    $log4 .= "maillog";
  }
}
close(LOGROTATE);
$logrotatestr = "/etc/logrotate.d/syslog has logratation configure for<br>".$log1 . $log2 . $log3 . $log4;
component_line_str("5.3 Configure logrotate","/etc/logrotate.d/syslog has logratation configure for<br>cron,messages,secure,maillog", $logrotatestr);

component_tail();
#################

#section6
component_head("6 System Access, Authentication and Authorization");
component_line_subhead("6.1 Configure cron and anacron");

$anacronstr = (check_package("cronie-anacron")) ? "cronie-anacron rpm is Installed" : "cronie-anacron not installed";
component_line_str("6.1.1 Enable anacron Daemon","cronie-anacron rpm is Installed", $anacronstr);

$crond_service_str = (check_service_enabled("crond")) ? "crond service is enabled" : "crond not enabled";
component_line_str("6.1.2 Enable crond Daemon","crond service is enabled", $crond_service_str);

%cronfiles = ("/etc/anacrontab", "000",
"/etc/crontab", "000",
"/etc/cron.hourly", "000",
"/etc/cron.daily", "000",
"/etc/cron.weekly", "000",
"/etc/cron.monthly", "000",
"/etc/cron.d", "000"
);
foreach $file (keys %cronfiles){
  $crontmp = `stat -L -c "Ownership: %U:%G Permissons:%a" $file`;
  chop $crontmp;
  $cronfiles{$file} = "$crontmp";
}

component_line_str("6.1.3 Set User/Group Owner and Permission on /etc/anacrontab","Ownership: root:root Permissons:600", $cronfiles{"/etc/anacrontab"});
component_line_str("6.1.4 Set User/Group Owner and Permission on /etc/crontab","Ownership: root:root Permissons:600", $cronfiles{"/etc/crontab"});
component_line_str("6.1.5 Set User/Group Owner and Permission on /etc/cron.hourly","Ownership: root:root Permissons:700", $cronfiles{"/etc/cron.hourly"});
component_line_str("6.1.6 Set User/Group Owner and Permission on /etc/cron.daily","Ownership: root:root Permissons:700", $cronfiles{"/etc/cron.daily"});
component_line_str("6.1.7 Set User/Group Owner and Permission on /etc/cron.weekly","Ownership: root:root Permissons:700", $cronfiles{"/etc/cron.weekly"});
component_line_str("6.1.8 Set User/Group Owner and Permission on /etc/cron.monthly","Ownership: root:root Permissons:700", $cronfiles{"/etc/cron.monthly"});
component_line_str("6.1.9 Set User/Group Owner and Permission on /etc/cron.d","Ownership: root:root Permissons:700", $cronfiles{"/etc/cron.d"});

$str6110 = "Not configured";
# The /etc/at.deny was removed from this check - it should be possible to have such file
#if ( ( ! -f "/etc/at.deny" ) && ( -f "/etc/at.allow" )){
if ( -f "/etc/at.allow" ){
 $at_allow_perm = `stat -L -c "%U:%G_%a" /etc/at.allow`;
 chop $at_allow_perm;
 if($at_allow_perm eq "root:root_600"){
   $str6110 = "/etc/at.allow - Present<br>/etc/at.allow Ownership: root:root Permissions: 600";
 }
}
component_line_str("6.1.10 Restrict at Daemon","/etc/at.allow - Present<br>/etc/at.allow Ownership: root:root Permissions: 600",$str6110);

$str6111 = "Not configured";
if ( ( ! -f "/etc/cron.deny") && ( -f "/etc/cron.allow")){
 $cron_allow_perm = `stat -L -c "%U:%G_%a" /etc/cron.allow`;
 chop $cron_allow_perm;
 if($cron_allow_perm eq "root:root_600"){
   $str6111 = "/etc/cron.deny - Not Present<br>/etc/cron.allow - Present<br>/etc/cron.allow Ownership: root:root Permissions: 600";
 }
}
component_line_str("6.1.11 Restrict at/cron to Authorized Users","/etc/cron.deny - Not Present<br>/etc/cron.allow - Present<br>/etc/cron.allow Ownership: root:root Permissions: 600", $str6111);

component_line_subhead("6.2 Configure SSH");

$ssh_protocol_str = (check_sshd_conf("Protocol", "2")) ? "/etc/ssh/sshd_config contains<br>Protocol 2" : "Not Found in sshd_config";
component_line_str("6.2.1 Set SSH Protocol to 2","/etc/ssh/sshd_config contains<br>Protocol 2", $ssh_protocol_str);

$ssh_loglevel_str = (check_sshd_conf("LogLevel", "INFO")) ? "/etc/ssh/sshd_config contains<br>LogLevel INFO" : "Not Found in sshd_config";
component_line_str("6.2.2 Set LogLevel to INFO","/etc/ssh/sshd_config contains<br>LogLevel INFO", $ssh_loglevel_str);

$ssh_perm_str = `stat -L -c "Ownership: %U:%G Permissions: %a" /etc/ssh/sshd_config`;
chomp $ssh_perm_str;
component_line_str("6.2.3 Set Permissions on /etc/ssh/sshd_config","Ownership: root:root Permissions: 600", $ssh_perm_str);

$ssh_x11_str = (check_sshd_conf("X11Forwarding", "no")) ? "/etc/ssh/sshd_config contains<br>X11 Forwarding no" : "Not Found in sshd_config";
component_line_str("6.2.4 Disable SSH X11 Forwarding","SKIPPED", "SKIPPED");

$ssh_MaxAuthTries_str = (check_sshd_conf("MaxAuthTries", "4")) ? "/etc/ssh/sshd_config contains<br>MaxAuthTries 4" : "Not Found in sshd_config";
component_line_str("6.2.5 Set SSH MaxAuthTries to 4 or Less","/etc/ssh/sshd_config contains<br>MaxAuthTries 4", $ssh_MaxAuthTries_str);

$ssh_IgnoreRhosts_str = (check_sshd_conf("IgnoreRhosts", "yes")) ? "/etc/ssh/sshd_config contains<br>IgnoreRhosts Yes" : "Not Found in sshd_config";
component_line_str("6.2.6 Set SSH IgnoreRhosts to Yes","/etc/ssh/sshd_config contains<br>IgnoreRhosts Yes", $ssh_IgnoreRhosts_str);

$ssh_hostAuth_str = (check_sshd_conf("HostbasedAuthentication", "no")) ? "/etc/ssh/sshd_config contains<br>HostbasedAuthentication no" : "Not Found in sshd_config";
component_line_str("6.2.7 Set SSH HostbasedAuthentication to No","/etc/ssh/sshd_config contains<br>HostbasedAuthentication no", $ssh_hostAuth_str);

$ssh_PermitRootLogin_str = (check_sshd_conf("PermitRootLogin", "yes")) ? "/etc/ssh/sshd_config contains<br>PermitRootLogin yes" : "Not Found in sshd_config";
component_line_str("6.2.8 Disable SSH Root Login","/etc/ssh/sshd_config contains<br>PermitRootLogin yes", $ssh_PermitRootLogin_str);

$ssh_PermitEmptyPasswords_str = (check_sshd_conf("PermitEmptyPasswords", "no")) ? "/etc/ssh/sshd_config contains<br>PermitEmptyPasswords no" : "Not Found in sshd_config";
component_line_str("6.2.9 Set SSH PermitEmptyPasswords to No","/etc/ssh/sshd_config contains<br>PermitEmptyPasswords no", $ssh_PermitEmptyPasswords_str);

$ssh_PermitUserEnvironment_str = (check_sshd_conf("PermitUserEnvironment", "no")) ? "/etc/ssh/sshd_config contains<br>PermitUserEnvironment no" : "Not Found in sshd_config";
component_line_str("6.2.10 Do Not Allow Users to Set Environment Options","/etc/ssh/sshd_config contains<br>PermitUserEnvironment no", $ssh_PermitUserEnvironment_str);

$ssh_Ciphers_str = (check_sshd_conf("Ciphers", "aes128-ctr,aes192-ctr,aes256-ctr")) ? "/etc/ssh/sshd_config contains<br>Chipners aes128-ctr,are192-ctr,aes256-ctr" : "Not Found in sshd_config";
component_line_str("6.2.11 Use Only Approved Cipher in Counter Mode","/etc/ssh/sshd_config contains<br>Chipners aes128-ctr,are192-ctr,aes256-ctr", $ssh_Ciphers_str);

$ssh_live_str = (check_sshd_conf("ClientAliveInterval", "300") && check_sshd_conf("ClientAliveCountMax", "720")) ? "/etc/ssh/sshd_config contains<br>ClientAliveInterval 300<br>ClientAliveCountMax 720" : "Not Found in sshd_config";
component_line_str("6.2.12 Set Idle Timeout Interval for User Login","/etc/ssh/sshd_config contains<br>ClientAliveInterval 300<br>ClientAliveCountMax 720", $ssh_live_str);

$ssh_blockapp_str = (check_sshd_conf("DenyGroups", "blockapp")) ? "/etc/ssh/sshd_config contains<br>DenyGroups blockapp" : "Not found in sshd_config";
component_line_str("6.2.13 Limit Access via SSH","/etc/ssh/sshd_config contains<br>DenyGroups blockapp", $ssh_blockapp_str);

$ssh_Banner_str = (check_sshd_conf("Banner", "/etc/issue")) ? "/etc/ssh/sshd_config contains<br>Banner /etc/issue" : "Not Found in sshd_config";
component_line_str("6.2.14 Set SSH Banner","/etc/ssh/sshd_config contains<br>Banner /etc/issue", $ssh_Banner_str);

component_line_subhead("6.3 Configure PAM");

$str631 = "Not set";
$str631 = ` authconfig --test | grep hashing | grep sha512`;
chop $str631;
$str631 = trim($str631);
component_line_str("6.3.1 Upgrade Password Hashing Algorithm to SHA-512","password hashing algorithm is sha512", $str631);

$system_auth = "/etc/pam.d/system-auth";
$str632 = "not configured";
$str633 = "not configured";
$str634 = "not configured";
$str632a = 0;
$str633a = 0;
open(SYSAUTH,$system_auth) || print "could not open file $system_auth \n";
while(<SYSAUTH>){
  chop;
  s/#.*//;
  next if /^\s*$/;
   if($_ =~ "pam_pwquality.so" ) {
    ($svc,$type,$mod) = /([a-z]+)\s+([a-z]+)\s+(.*)/;
    if($svc eq "password" && $type eq "requisite" && $mod =~ "pam_pwquality.so difok=1 minlen=8 minclass=3 retry=5"){
	  $str632a = 1;
	}
  }elsif($_ =~ "pam_faillock.so preauth"){
   ($svc1,$type1,$mod1) = /([a-z]+)\s+([a-z]+)\s+(.*)/;
   if($svc1 eq "auth" && $type1 eq "required" && $mod1 =~ "pam_faillock.so preauth audit silent deny=5" ){
     $str633a = 1;
   }
  }elsif($_ =~ "pam_unix.so sha512"){
    ($svc2,$type2,$mod2) = /([a-z]+)\s+([a-z]+)\s+(.*)/;
	 ($reuse) = (split, $mod2)[-1];
	if($svc2 eq "password" && $type2 eq "sufficient" && $reuse =~ "remember=5"){
	  $str634 = "/etc/pam.d/system-auth contains remember = 5";
	}
  }
}
close(SYSAUTH);

$pwquality="/etc/security/pwquality.conf";
$minlen = $dcredit = $ucredit = $ocredit = $lcredit = 0;
open(PWQ,$pwquality) || print "could not open file $pwquality \n";
while(<PWQ>){
  chop;
  s/#.*//;
  next if /^\s*$/;
  ($parm, $val) = split /=/;
   $parm = trim($parm);
   $val = trim($val);
   if($parm eq "difok" && $val == 1){
     $difok = 1;
   }elsif($parm eq "minlen" && $val == 8){
     $minlen = 1;
   }elsif($parm eq "minclass" && $val == 3){
     $minclass = 1;
   }elsif($parm eq "retry" && $val == 5){
     $retry = 1;
   }
}
close(PWQ);
if( ($str632a) && ($difok) && ($minlen) && ($minclass) && ($retry)){
 $str632 = "/etc/pam.d/system-auth contains pam_pwquality.so<br>/etc/security/pwquality.conf contains<br>difok=1<br>minlen=8<br>minclass=3<br>retry=5";
}
component_line_str("6.3.2 Set Password Creation Requirement Parameters Using","/etc/pam.d/system-auth contains pam_pwquality.so<br>/etc/security/pwquality.conf contains<br>difok=1<br>minlen=8<br>minclass=3<br>retry=5", $str632);

$password_auth=`grep -c "pam_faillock" /etc/pam.d/password-auth`;
chop $password_auth;
if($password_auth > 1 && $str633a == 1){
  $str633 = "/etc/pam.d/password-auth and /etc/pam.d/system-auth contains auth settings to lock passwords";
}
component_line_str("6.3.3 Set Lockout for Failed Password Attempts","/etc/pam.d/password-auth and /etc/pam.d/system-auth contains auth settings to lock passwords", $str633);

component_line_str("6.3.4 Limit Password Reuse","/etc/pam.d/system-auth contains remember = 5",$str634);

@approved_ttys=(tty1,tty2,tty3,tty4,tty5,tty6);
@ttys_found=();
$ttyfile = "/etc/securetty";
open(TTY,$ttyfile) or print "can not open file $ttyfile \n";
while(<TTY>){
  chop;
  push (@ttys_found, $_);
}
close(TTY);

foreach( 0 .. $#approved_ttys){
  if ($approved_ttys[$_] != $ttys_found[$_]){
    $str64 = "ttys not properly configured";
  }else {
    $str64 = "/etc/securetty contains<br>tty1<br>tty2<br>tty3<br>tty4<br>tty5<br>tty6";
  }
}

component_line_str("6.4 Restrict root Login to System Console","/etc/securetty contains<br>tty1<br>tty2<br>tty3<br>tty4<br>tty5<br>tty6",$str64);

$str65 = "Not configured";
$suaccess=`grep -o "group=se" /etc/pam.d/su`;
chop $suaccess;
if ($suaccess eq "group=se"){
  $str65 = "/etc/pam.d/su contains pam_wheel.so setting";
}
component_line_str("6.5 Restrict Access to the su Command","/etc/pam.d/su contains pam_wheel.so setting",$str65);


component_tail();
################

#section7
component_head("7 User Accounts and Environment");
component_line_subhead("7.1 Set Shadow Password Suite Parameters (/etc/login.defs)");

$login_defs="/etc/login.defs";
$str711 = $str712 = $str713 = "Not configured";
open(LOGIN,$login_defs) or print "could not open $login_defs \n";
while(<LOGIN>){
  chop;
  s/#.*//;
  next if /^\s*$/;
  ($parm, $val) = split;
  $parm = trim($parm);
  $val = trim($val);
  if($parm eq "PASS_MAX_DAYS" && $val == 90){
    $str711 = "/etc/login.defs contains PASS_MAX_DAYS 90";
  }elsif($parm eq "PASS_MIN_DAYS" && $val == 1){
    $str712 = "/etc/login.defs contains PASS_MIN_DAYS 1";
  }elsif($parm eq "PASS_WARN_AGE" && $val == 14){
    $str713 = "/etc/login.defs contains PASS_WARN_AGE 14";
  }
}
component_line_str("7.1.1 Set Password Expiration Days","/etc/login.defs contains PASS_MAX_DAYS 90", $str711);
component_line_str("7.1.2 Set Password Change Minimum Number of Days","/etc/login.defs contains PASS_MIN_DAYS 1", $str712);
component_line_str("7.1.3 Set Password Expiring Warning Days","/etc/login.defs contains PASS_WARN_AGE 14", $str713);

$str72 = "cron jon does not exist";
if ( -e "/etc/cron.d/system_accounts"){
  $str72 = "cron job exist to make sure system accounts can not be accessed";
}
component_line_str("7.2 Disable System Accounts","cron job exist to make sure system accounts can not be accessed", $str72);

$str73 = "root GID Not set to 0";
$rootgid=`grep "^root:" /etc/passwd | cut -f4 -d:`;
chop $rootgid;
if ($rootgid == 0){
  $str73 = "root GID set to 0";
}
component_line_str("7.3 Set Default Group for root Account","root GID set to 0", $str73);

$str74 = "Umask not present";
$str74a=`grep "^umask 77" /etc/bashrc`;
chop $str74a;
if ( (-f "/etc/profile.d/cis.sh") && ($str74a eq "umask 77")){
  $str74 = "umask 077 set in /etc/bashrc and<br>/etc/profile.d/cis.sh";
}
component_line_str("7.4 Set Default umask for Users","umask 077 set in /etc/bashrc and<br>/etc/profile.d/cis.sh", $str74);

$str75 = "Not set";
$str75a=`useradd -D | grep INACTIVE`;
chop $str75a;
if( $str75a eq "INACTIVE=45"){
  $str75 = "INACTIVE set to 45 days";
}
component_line_str("7.5 Lock Inactive User Accounts","INACTIVE set to 45 days", $str75);

component_tail();
################

#section8
component_head("8 Warning Banners");

$str81 = "Not set";
if ( -f "/etc/issue"){
  $issue_perm = `stat -L -c "%U:%G_%a" /etc/issue`;
  chop $issue_perm;
  if( $issue_perm eq "root:root_644"){
    $str81 = "/etc/issue file is present<br>/etc/issue Ownership->root:root, Permissions->644";
  }
}
component_line_str("8.1 Set Warning Banner for Standard Login Services","/etc/issue file is present<br>/etc/issue Ownership->root:root, Permissions->644", $str81);

$str82 = "Not removed";
$str82a=`egrep -c '(\\v|\\r|\\m|\\s)' /etc/issue`;
chop $str82a;
$str82b=`egrep -c '(\\v|\\r|\\m|\\s)' /etc/motd`;
chop $str82b;

$etc_issue = "/etc/issue";
$etc_motd = "/etc/motd";
$str82a = 0;
$str82b = 0;
open(ISSUE,$etc_issue) or print "could not open file : $etc_issue";
while(<ISSUE>){
  chop;
   s/#.*//;
   next if /^\s*$/;
   (@words) = split;
   foreach (@words){
    if($_ eq "\v" || $_ eq "\r" || $_ eq "\s" || $_ eq "m"){
	  $str82a = 1;
	  last;
	}
   }
}
close(ISSUE);
open(MOTD,$etc_motd) or print "could not open file : $etc_motd";
while(<MOTD>){
  chop;
   s/#.*//;
   next if /^\s*$/;
   (@words) = split;
   foreach (@words){
    if($_ eq "\v" || $_ eq "\r" || $_ eq "\s" || $_ eq "\m"){
	  $str82b = 1;
	  last;
	}
   }
}

if( ($str82a == 0) && ($str82b == 0)){
  $str82 = "OS information removed from /etc/motd,/etc/issue";
}
component_line_str("8.2 Remove OS Information from Login Warning Banners","OS information removed from /etc/motd,/etc/issue", $str82);

$str83 = (check_package("gdm")) ? "gdm installed" : "gdm not used";
component_line_str("8.3 Set GNOME Warning Banner","gdm not used", $str83);

component_tail();
################
#section9
component_head("9 System Maintenance");
component_line_subhead("9.1 Verify System File Permissions");

component_line_str("9.1.1 Verify System File Permissions","cron exist to collect the installed rpm details", (-f "/etc/cron.d/checkrpms") ? "cron exist to collect the installed rpm details" : "Not setup");

@sec9 = ("/etc/passwd","/etc/shadow","/etc/gshadow","/etc/group");
%sec9_owners = ("/etc/passwd","0","/etc/shadow","0","/etc/gshadow","0","/etc/group","0");
%sec9_perms = ("/etc/passwd","0","/etc/shadow","0","/etc/gshadow","0","/etc/group","0");
foreach (@sec9){
 $owner9=`stat -L -c "%U:%G" $_`;
 $perm9=`stat -L -c "%a" $_`;
 chop $perm9;
 chop $owner9;
 $sec9_owners{$_} = "$_ ownership: $owner9";
 $sec9_perms{$_} = "$_ permissions: $perm9";
}
component_line_str("9.1.2 Verify Permissions on /etc/passwd","/etc/passwd permissions: 644", $sec9_perms{'/etc/passwd'});
component_line_str("9.1.3 Verify Permissions on /etc/shadow","/etc/shadow permissions: 0", $sec9_perms{'/etc/shadow'});
component_line_str("9.1.4 Verify Permissions on /etc/gshadow","/etc/gshadow permissions: 0", $sec9_perms{'/etc/gshadow'});
component_line_str("9.1.5 Verify Permissions on /etc/group","/etc/group permissions: 644", $sec9_perms{'/etc/group'});
component_line_str("9.1.6 Verify User/Group Ownership on /etc/passwd","/etc/passwd ownership: root:root", $sec9_owners{'/etc/passwd'});
component_line_str("9.1.7 Verify User/Group Ownership on /etc/shadow","/etc/shadow ownership: root:root", $sec9_owners{'/etc/shadow'});
component_line_str("9.1.8 Verify User/Group Ownership on /etc/gshadow","/etc/gshadow ownership: root:root", $sec9_owners{'/etc/gshadow'});
component_line_str("9.1.9 Verify User/Group Ownership on /etc/group","/etc/group ownership: root:root", $sec9_owners{'/etc/group'});

$str9110 = "No. of World Writable Files are : 0";
#$cmd9110="df --local -P | awk {'if (NR!=1) print \$6'} | xargs -I '{}' find '{}' -xdev -type f -perm -0002";
$cmd9110=`echo`;
@wwfiles=`$cmd9110`;
if( $#wwfiles > 0) {
  $str9110 = "World Writable Files are : $#wwfiles";
}
component_line_str("9.1.10 Find World Writable Files","No. of World Writable Files are : 0", $str9110);

$str9111 = "Un-owned Files are : 0";
#$cmd9111="df --local -P | awk {'if (NR!=1) print \$6'} | xargs -I '{}' find '{}' -xdev -nouser -ls";
$cmd9111=`echo`;
@array9111=`$cmd9111`;
if( $#array9111 > 0){
  $str9111 = "Un-owned Files are : $#array9111";
}
component_line_str("9.1.11 Find Un-owned Files and Directories","Un-owned Files are : 0", $str9111);

$str9112 = "Un-grouped Files are : 0";
#$cmd9112="df --local -P | awk {'if (NR!=1) print \$6'} | xargs -I '{}' find '{}' -xdev -nogroup -ls";
$cmd9112=`echo`;
@array9112=`$cmd9112`;
if( $#array9112 > 0){
  $str9112 = "Un-grouped Files are : $#array9112";
}
component_line_str("9.1.12 Find Un-grouped Files and Directories","Un-grouped Files are : 0", $str9112);

$str9113 = "not copied";
$cmd9113=`df --local -P | awk {'if (NR!=1) print \$6'} | xargs -I '{}' find '{}' -xdev -type f -perm -4000 -print > /var/log/setUID.log`;
#$cmd9113=`echo`;
if(($?>>8) == 0){
  $str9113 = "set-UID programs copied to /var/log/setUID.log for review";
}
component_line_str("9.1.13 Find SUID System Executables","set-UID programs copied to /var/log/setUID.log for review", $str9113);

$str9114 = "not copied";
$cmd9114=`df --local -P | awk {'if (NR!=1) print \$6'} | xargs -I '{}' find '{}' -xdev -type f -perm -2000 -print > /var/log/seGID.log`;
#$cmd0114=`echo`;
if(($?>>8) == 0){
  $str9114 = "set-GID programs copied to /var/log/setGID.log for review";
}
component_line_str("9.1.14 Find SGID System Executables","set-GID programs copied to /var/log/setGID.log for review", $str9114);

component_line_subhead("9.2 Review User and Group Settings");

$shadow="/etc/shadow";
$str921 = "Accounts with empty passwords : 0";
@emptyAccounts = ();
open(SHADOW,$shadow) or print "could not open $shadow file \n";
while(<SHADOW>){
  chop;
  ($acct,$pass,@exp) = split /:/;
  if($pass eq ''){
    push (@emptyAccounts, $acct);
  }
}
close(SHADOW);
if( $#emptyAccounts > 0){
  $str921 = "Accounts with empty passwords : $#emptyAccounts";
}
component_line_str("9.2.1 Ensure Password Fields are Not Empty","Accounts with empty passwords : 0", $str921);

%str922 = ("/etc/passwd","none","/etc/shadow","none","/etc/group","none");
foreach (keys %str922) {
  $str922a=`/bin/grep -c '^+:' $_`;
  chop $str922a;
  if ($str922a == 0){
    $str922{$_} = "$_ does not have legacy + entries";
  }
}
component_line_str("9.2.2 Verify No Legacy "+" Entries Exist in /etc/passwd File","/etc/passwd does not have legacy + entries", $str922{'/etc/passwd'});
component_line_str("9.2.3 Verify No Legacy "+" Entries Exist in /etc/shadow File","/etc/shadow does not have legacy + entries", $str922{'/etc/shadow'});
component_line_str("9.2.4 Verify No Legacy "+" Entries Exist in /etc/group File","/etc/group does not have legacy + entries", $str922{'/etc/group'});

$passwd_file="/etc/passwd";
$acct0 = "";
$str925 = "No Accounts with UID 0 except root";
%homedirs=();
%usershells=();
%userids=();
@groups_in_passwd=();
open(PASSWD,$passwd_file) or print "could not open file $passwd_file \n";
while(<PASSWD>){
  chop;
  ($user,$pass,$uid,$gid,$comment,$homedir,$shell) = split /:/;
  $homedirs{$user} = $homedir;
  $usershells{$user} = $shell;
  $userids{$user} = $uid;
  push (@groups_in_passwd, $gid);
  if ($uid == 0 ){
    $acct0 = $user;
  }
}
close(PASSWD);
if($acct0 ne "root"){
 $str925 = "$uid_check has uid : 0";
}
component_line_str("9.2.5 Verify No UID 0 Accounts Exist Other Than root","No Accounts with UID 0 except root", $str925);

@path = split(/:/,$ENV{PATH});
$str926 = "PATH variable configured properly";
foreach (@path){
  if( -d $_ ) {
  my $sb = stat( $_ );
  my $mode = $sb->mode & 0777;
  if($_ eq "." || ($mode & 022)){
    $str926 = "PATH variable not configured properly";
  }
  }
}
component_line_str("9.2.6 Ensure root PATH Integrity","PATH variable configured properly", $str926);

$str927 = "not setup";
foreach (keys %homedirs){
  next if ($_ eq "root" || $_ eq "halt" || $_ eq "sync" || $_ eq "shutdown");
  if ( -d $homedirs{$_} ) {
  my $sb = stat( $homedirs{$_} );
  my $mode = $sb->mode & 0777 ;
    if ( ! ($mode & 022)) {
      $str927 = "world writable user home dirs : 0";
    }
  }
}
component_line_str("9.2.7 Check Permissions on User Home Directories","world writable user home dirs : 0", $str927);

$str928 = "not setup";
$str929 = "not setup";
$str9210 = "not setup";
$str9210a = 0;
foreach (keys %homedirs){
  next if ($_ eq "root" || $_ eq "halt" || $_ eq "sync" || $_ eq "shutdown");
  my $dir = $homedirs{$_};
  if ( -f "$dir/.rhosts" ){
    $str9210a++;
  } 
  my @files =  <$dir/.*>;
  #print "$dir: $#files \n";
 if ($#files > 0){
  foreach (@files){
    #print "$_ \n";
    my $sb = stat ( $_ );
	my $mode = $sb->mode & 0777;
	if( ! ($mode & 022)){
	 $str928 = "world writable dot files in user home dirs : 0";
	 $str929 = "world writable .netrc files in user home dirs : 0";
	}
  }
 }else {
   $str928 = "world writable dot files in user home dirs : 0";
   $str929 = "world writable .netrc files in user home dirs : 0";
 }
}
component_line_str("9.2.8 Check User Dot File Permissions","world writable dot files in user home dirs : 0", $str928);
component_line_str("9.2.9 Check Permissions on User .netrc Files","world writable .netrc files in user home dirs : 0", $str929);

$str9210 = "No of rhosts files in user home dirs : " . $str9210a;
component_line_str("9.2.10 Check for Presence of User .rhosts Files","No of rhosts files in user home dirs : 0", $str9210);

$etc_group="/etc/group";
%gids_actual=();
open(GROUP,$etc_group) or print "could not open file $etc_group \n";
while(<GROUP>){
  chop;
  ($grpname,$gpasswd,$gid) = split /:/;
  $gids_actual{"$grpname"} = $gid;
}
close(GROUP);

$str9211 = "Undefined groups in /etc/groups : 0";
foreach my $id (@groups_in_passwd){
 if (! grep {$_ == $id } values %gids_actual)
 {
   $str9211 = "$id Not found in /etc/group";
 }
}
component_line_str("9.2.11 Check Groups in /etc/passwd","Undefined groups in /etc/groups : 0", $str9211);

$str9212 = "No user found without a home directory";

foreach my $user (keys %userids){
  my $id = $userids{$user};
  next if (($id < 1000) || ($user eq "nfsnobody") || ($user eq "avahi-autoipd") || ($user eq "chrony"));
  if( ! -d $homedirs{$user}){
    $str9212 = "$user home directory not found";
  } 
}
component_line_str("9.2.12 Check That Users Are Assigned Valid Home Directories","No user found without a home directory", $str9212);

$str9213 = "home directory ownership is fine";
foreach my $user (keys %userids){
  my $id = $userids{$user};
  next if (($id < 1000) || ($user eq "nfsnobody") || ($user eq "avahi-autoipd") || ($user eq "chrony"));
  my $owner = `stat -L -c "%U" $homedirs{$user}`;
  chop $owner;
  if ($user ne $owner)
  {
    $str9213 = "$user home directory owned by $owner";
  }
}
component_line_str("9.2.13 Check User Home Directory Ownership","home directory ownership is fine", $str9213);

%seen;
$str9214 = "UIDs are unique";
foreach my $eachid (values %userids) {
  next unless $seen{$eachid}++;
  $str9214 = "$eachid is duplicated";
}
component_line_str("9.2.14 Check for Duplicate UIDs","UIDs are unique", $str9214);

%seengid;
$str9215 = "GIDs are unique";
foreach my $eachgid (values %gids_actual) {
  next unless $seengid{$eachgid}++;
  $str9215 = "$eachgid is duplicated";
}
component_line_str("9.2.15 Check for Duplicate GIDs","GIDs are unique", $str9215);

@defUsers=("root","bin","daemon","adm","lp","sync","shutdown","halt","mail","news","uucp","operator","games",
"gopher","ftp","nobody","nscd","vcsa","rpc","mailnull","smmsp","pcap","ntp","dbus","avahi","sshd","rpcuser","nfsnobody","haldaemon",
"avahi-autoipd","distcache","apache","oprofile","webalizer","dovecot","squid","named","xfs","gdm","sabayon","usbmuxd","rtkit","abrt",
"saslauth","pulse","postfix","tcpdump");

$str9216 = "Reserved UIDs are not assigned to non-system accounts";
foreach my $user (keys %userids){
  my $id = $userids{$user};
  next if (($id < 1000) || ($user eq "nfsnobody"));
  if (grep {$_ eq $user} @defUsers){
    $str9216 = "$user id not in reserved range";
  }
}
component_line_str("9.2.16 Check That Reserved UIDs Are Assigned to System Accounts","Reserved UIDs are not assigned to non-system accounts", $str9216);

%seenuser;
$str9217 = "No Duplicate User Names found";
foreach my $eachuser (keys %userids) {
  next unless $seenuser{$eachuser}++;
  $str9217 = "$eachuser is duplicated";
}
component_line_str("9.2.17 Check for Duplicate User Names","No Duplicate User Names found", $str9217);

%seengroup;
$str9218 = "No Duplicate Group Names found";
foreach my $eachgrp (keys %gids_actual) {
  next unless $seengroup{$eachgrp}++;
  $str9218 = "$eachgrp is duplicated";
}
component_line_str("9.2.18 Check for Duplicate Group Names","No Duplicate Group Names found", $str9218);


$str9219a=0;
$str9220a=0;
foreach (keys %homedirs){
  next if ($_ eq "root" || $_ eq "halt" || $_ eq "sync" || $_ eq "shutdown" || $_ eq "bin");
  my $dir = $homedirs{$_};
  #print "-> $dir \n";
  if ( -f "$dir/.netrc" ){
    $str9219a++;
  }elsif( -f "$dir/.forward"){
    $str9220a++;
  }
 }
 
$str9219 = "No of .netrc files in user home dirs : " . $str9219a;
component_line_str("9.2.19 Check for Presence of User .netrc Files ","No of .netrc files in user home dirs : 0", $str9219);
component_line_str("9.2.20 Check for Presence of User .forward Files","In Progress", "In Progress");


component_tail();
################
################

component_head("Netbackup Agent Installation");
if ($serverinfo{'netbackupservers'}[0] eq "N/A") {
  component_line_str("Installation of Netbackup Agent", "N/A", "N/A");
} else {
  $status = `grep bpcd /etc/services | wc -l`;
  chop $status;
  $version="0.0.0";
  if ( -f "/usr/openv/netbackup/bin/version" )
  {
    $version = `cat /usr/openv/netbackup/bin/version | awk '{print \$2}'`;
    chop $version;
  }
  (-f "/usr/openv/netbackup/NET_BUFFER_SZ")? $netbufsz = `cat /usr/openv/netbackup/NET_BUFFER_SZ` : $netbufsz="0.0.0";
  chop $netbufsz;
  component_line_ver_num("Netbackup", "7.6.0.3", $version, ">=");
  component_line_str("bpcd defined in /etc/services", "OK", ($status == 2)? "OK" : "Not OK");
  component_line_str("Listening on port 13782", "OK", check_listening(13782));
}
component_tail();
################
component_head("SCOM Agent Installation");
if ($serverinfo{'ovoserver'}[0] eq "N/A") {
  component_line_str("Installation of SCOM Agent", "N/A", "N/A");
} else {
  component_line_str("Service scx-cimd running", "OK", check_service_running("scx-cimd"));
  component_line_str("scx-cimd startup", "enabled", (check_service_enabled("scx-cimd")) ? "enabled" : "disabled");
}
component_tail();
################
component_head("Centrify Agent Installation");
if ($serverinfo{'centrify'}[0] eq "N/A") {
  component_line_str("Installation of Centrify Agent", "N/A", "N/A");
} else {
  check_rpmpkg_version("CentrifyDC", "5.2.1", ">=");
  component_line_str("centrifydc startup", "enabled", (check_service_enabled("centrifydc")) ? "enabled" : "disabled");
  if ($serverinfo{'zone'}[0] eq "N/A" || $serverinfo{'zone'}[0] eq "" ) {
    component_line_str("CentrifyDC mode", "N/A", "N/A");
  } else {
    $mode=`adinfo -m`;
    chomp $mode;
    component_line_str("CentrifyDC mode", "connected", $mode);
  }
}
component_tail();
################
component_head("TrendMicro Installation");
check_rpmpkg_version("ds_agent", "9.5.3", ">=");
$AntiVirusVersion=`rpm -q ds_agent --qf %{VERSION}`;
component_line_str("ds_agent startup", "enabled", (check_service_enabled("ds_agent")) ? "enabled" : "disabled");
component_tail();


################
component_head("ReaR Installation");
# Next line was buggy - removed =N/A from rear_netfs_url=N/A and changed = into eq
if ($serverinfo{'rear_netfs_url'}[0] eq "N/A") {
  component_line_str("rear", "N/A", "N/A");
} else {
  check_rpmpkg_version("rear", "1.17.2", ">=");
}
component_tail();

################

################
component_head("Chef Cookbooks");
# Section added by Gratien Dhaese
check_rpmpkg_version("chef", "12.19.36" , ">=");
# knife node show $( tr '[A-Z]' '[a-z]' <<< $(hostname -s) )  -c /etc/chef/client.rb | grep ^Roles | awk '{print $2}'
# output: jnj_core
$lhost=`hostname -s | tr '[A-Z]' '[a-z]'`;
chop $lhost;
$chef_role=`knife node show $lhost -c /etc/chef/client.rb | grep ^Roles | awk '{print \$2}'`;
chop $chef_role;
component_line_str("chef-role", "jnj_core", $chef_role);
component_tail();


################
component_head("Account Tools Installation");
check_rpmpkg_version("acctutil", "1.1", ">=");
check_rpmpkg_version("secutil", "2.5", ">=");
# idmsnags rpm was removed (by Chef)
#check_rpmpkg_version("idmsnags", "1.2", ">=");
check_version("/opt/idms/nags/nagsCollector.sh", "1.32", ">=");
$nagscollector=`crontab -l | grep nagsCollector.sh | wc -l`;
chop $nagscollector;
component_line_num("crontab entry for nagsCollector", 1, $nagscollector, "==");
component_line_str("Account Utils Cron entries","cron entries configured", ( -f "/etc/cron.d/acctutil" ) ? "cron entries configured" : "Not configured");
component_line_str("Security Utils Cron entries","cron entries configured", ( -f "/etc/cron.d/secutil" ) ? "cron entries configured" : "Not configured");

component_tail();

################
component_head("Tidal Agent Installation");
$tidalAgentDir     = "Not Configured";
$tidalAgentUser    = "Not Configured";
$tidalAgentMount   = "Not Configured";

# TIDAL will be replaced with Workload Automation
#------------------------------------------------
# We skip this check
#$tidal_dir = '/opt/TIDAL/Agent';
$tidal_dir = '/opt/TIDAL/Agentxxx';
if ( -e $tidal_dir and -d $tidal_dir ) {
  $tidalAgentDir = "Configured";

$tidaluid=`id -u tidal`;
chop $tidaluid;
  if ( $tidaluid == 3112) {
  $tidalAgentUser = "Configured";
  }
$tidalMountCount = (check_if_mount_point("/opt/TIDAL")) ? "/opt/TIDAL is mounted" : "/opt/TIDAL not mounted";

component_line_str("Tidal Agent Dir : /opt/TIDAL/Agent","Configured",$tidalAgentDir);
component_line_str("Tidal User ","Configured",$tidalAgentUser);
component_line_str("Tidal Agent Mount : /opt/TIDAL","/opt/TIDAL is mounted",$tidalMountCount);
component_line_str("Tidal Agent Service","enabled",( check_service_enabled("tagent.service") ) ? "enabled" : "disabled");

} else {
  component_line_str("Tidal Agent","Not Applicable","Not Applicable");
}
component_tail();

################
component_head("RHEL7.4 Yum Repos");
$baserepo   = "Not Configured";
$agentrepo  = "Not Configured";
$optional = "Not Configured";
$tools   = "Not Configured";
$rh72channel = `rhn-channel -b`;
chop $rh72channel;
if ( ! "$rh72channel" =~  "JNJ-rhel-x86_64-server-7.4" ) {

  if ( -e "/etc/yum.repos.d/JNJ-rhel-x86_64-server-7-20171018.repo" ) {
    $baserepo = "Configured";
  }
  if ( -e "/etc/yum.repos.d/JNJ-rhel-x86_64-server-optional-7-20171018.repo") {
     $optional = "Configured";
  }
  if ( -e "/etc/yum.repos.d/JNJ-rhn-tools-rhel-x86_64-server-7-20171018.repo") {
     $tools = "Configured";
  }
  component_line_str("RHEL7.4 Base Repo",   "Configured",$baserepo);
  component_line_str("RHEL7.4 optional Repo", "Configured",$optional);
  component_line_str("RHEL7.4 tools Repo",   "Configured",$tools);
}

if ( -e "/etc/yum.repos.d/RHEL7_4_Agents.repo") {
     $agentrepo = "Configured";
}
component_line_str("RHEL7.4 Agents Repo", "Configured",$agentrepo);



component_tail();

################
component_head("VMware Tools Installation");
$serverType=`dmidecode -s system-product-name|awk '{print \$1}'`;
chop $serverType;
if ($serverType =~ "VMware") {
   $netmodule="vmxnet3";
  component_line_str("$netmodule module loaded", "Loaded", check_module($netmodule));
  foreach $dev (@nics1) {
    next if $dev =~ '^bond';
    $devmodule=readlink "/sys/class/net/$dev/device/driver";
    $devmodule =~ s/.*\///;
    component_line_str("$dev module", $netmodule, $devmodule);
  }
  $version = `/usr/bin/vmware-toolbox-cmd -v | cut -d'-' -f2 | cut -d')' -f1`;
  chop $version;
  component_line_ver_num("VMwareTools build version", "4542894", $version, ">=");
  $timesync = `/usr/bin/vmware-toolbox-cmd timesync status`;
  chop $timesync;
  component_line_str("VMware timesync", "Disabled", $timesync);
 } else {
  component_line_str("Installation of VMware Tools", "N/A", "N/A");
}
component_tail();

################
component_head("Hardware Support Tools and Drivers");

$serverType=`dmidecode -s system-product-name|awk '{print \$1}'`;
chop $serverType;
if (($serverinfo{'hpsimservers'}[0] eq "N/A") || ($serverType =~ "VMware") ) {
  component_line_str("Installation of Proliant Support Pack", "N/A", "N/A");
} else {
  check_rpmpkg_version("fibreutils", "3.2", ">=");
  check_rpmpkg_version("HP-CNA-FC-Emulex-Enablement-Kit", "10.7.110.34", ">=");
  check_rpmpkg_version("hp-ams", "2.4.0", ">=");
  check_rpmpkg_version("hp-health", "10.40", ">=");
  check_rpmpkg_version("hpdiags", "10.50.2007", ">=");
  check_rpmpkg_version("hponcfg", "4.6.0", ">=");
  check_rpmpkg_version("kmod-elx-lpfc", "10.7.110.34", ">=");
  check_rpmpkg_version("kmod-hp-ixgbe", "4.1.5", ">=");
  check_rpmpkg_version("kmod-hpsa", "3.4.14", ">=");
	
  $strhw2 = (check_service_enabled("hp-health") ? "hp-health service enabled" : "Not enabled");
  component_line_str("hp-health startup", "hp-health service enabled", $strhw2);

  $asrstatus=`/sbin/hplog  -a STATUS | sed -e "s/ and.*//" -e "s/.* is //"`;
  chop $asrstatus;
  component_line_str("ASR status", "DISABLED", $asrstatus);
}
component_tail();

############



server_tail();

print OUTPUT "</HTML>\n";
close(OUTPUT);
close(SUMM);
close(RESULT);

# merge summary table into iq report
system("sed -i -e '/ADD_RESULT/r $LOGFILE.result' $LOGFILE");
system("sed -i -e '/ADD_SUMMARY/r $LOGFILE.summ' $LOGFILE");
