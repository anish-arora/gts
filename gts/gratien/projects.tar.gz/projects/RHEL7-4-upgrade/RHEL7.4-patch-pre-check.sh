#!/bin/bash
#################################################################
# This script will check if pre-requisites exist for
## RHEL upgrade Pre-Check
## Added JSON format output

os_version_bit=0x01
os_agents_bit=0x02
disk_check_bit=0x03

ret_code=0
#echo $ret_code

EXITCODE=0
source /etc/jnj-install/config
# Determine current kernel version
KERNEL=$(uname -r)
CURRENTKERNEL=${KERNEL%-*}
echo Set CURRENTKERNEL to ${CURRENTKERNEL}

echo
echo $(date +%T)
os_version=0
REDHAT_VERSION=$(rpm -qa --queryformat '%{VERSION}\n' 'redhat-release-server' | awk -F. '{print $1}' | cut -c1)
echo "Current Red Hat version is ${REDHAT_VERSION}"
if [[ ${REDHAT_VERSION} -ne 7 ]] ; then
  echo "ERROR: $(hostname) Cannot patch to RHEL 7.x"
  EXITCODE=1
  ret_code=$(($ret_code|$os_version_bit))
  os_version=1
fi

echo
echo $(date +%T)
os_agents=0
echo "Checking for LinuxShield..."
rpm -q MFEcma
if [[ $? -eq 0 ]] ; then
  echo "ERROR: $(hostname) LinuxShield Installed"
  EXITCODE=1
  ret_code=$(($ret_code|$os_agents_bit))
  os_agents=1
fi


echo "Checking for OVO and remove if installed."
if [[ -d /opt/OV/bin ]] ; then
  /opt/OV/bin/OpC/install/oainstall.sh -r -a
fi
echo
echo $(date +%T)
echo "Checking for OVO"
os_agents=0
if [[ -d /opt/OV/bin ]] ; then
  /sbin/chkconfig --list OVCtrl
  if [[ $? -eq 0 ]] ; then
    echo "WARNING: $(hostname) OVO Installed"
  EXITCODE=1
  ret_code=$(($ret_code|$os_agents_bit))
  os_agents=1
  fi
fi

echo
echo $(date +%T)
echo "Checking disk space requirements"
disk_check=0
root_avail=$(df --direct -m / | tail -1 | awk '{print $4}')
if [[ ${root_avail} -lt 1000 ]] ; then
  echo "ERROR: $(hostname) insufficient space available in /"
  EXITCODE=1
  ret_code=$(($ret_code|$disk_check_bit))
  disk_check=1
fi
boot_avail=$(df --direct -m /boot | tail -1 | awk '{print $4}')
if [[ ${boot_avail} -lt 20 ]] ; then
  echo "ERROR: $(hostname) insufficient space available in /boot"
  EXITCODE=1
  ret_code=$(($ret_code|$disk_check_bit))
  disk_check=1
fi
tmp_avail=$(df --direct -m /tmp | tail -1 | awk '{print $4}')
if [[ ${tmp_avail} -lt 1000 ]] ; then
  echo "ERROR: $(hostname) insufficient space available in /tmp"
  EXITCODE=1
  ret_code=$(($ret_code|$disk_check_bit))
  disk_check=1
fi
var_avail=$(df --direct -m /var | tail -1 | awk '{print $4}')
if [[ ${var_avail} -lt 1200 ]] ; then
  echo "ERROR: $(hostname) insufficient space available in /var"
  EXITCODE=1
  ret_code=$(($ret_code|$disk_check_bit))
  disk_check=1
fi

cat <<EOF > /var/adm/install-logs/precheck_result.json
 { "os_version" : "$os_version" , "disk_check" : "$disk_check" , "os_agents" : "$os_agents" }
EOF

if [[ ${EXITCODE} -ne 0 ]] ; then
  echo "ERROR: $(hostname) RHEL 7 Pre-Check failures found. ret_code => $ret_code"
  exit $ret_code
else
  echo "$(hostname) ready for RHEL7.x patching. ret_code => $ret_code"
  exit $ret_code
fi

