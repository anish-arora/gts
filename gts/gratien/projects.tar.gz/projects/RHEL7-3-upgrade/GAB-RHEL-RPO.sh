#! /bin/bash
########################################################################
# Script Name          : GAB-RHEL7-RPO.sh
# Author               : Akshay Orpe
# Description          : This script adds the RHEL7 YUM update repos
#                        to the system.
########################################################################



# turn on debugging
set -x

dmlserver=$(grep '^dmlurl' /etc/jnj-install/config | cut -d/ -f3) 
if [[ "${dmlserver}" == "" ]] ; then
  dmlserver=itsusablsp00956.jnj.com
fi

cat > /etc/yum.repos.d/JNJ-rhel-x86_64-server-7-201703.repo <<-EOF
[JNJ-rhel-x86_64-server-7-201703]
name=JNJ-rhel-x86_64-server-7-201703
baseurl=http://${dmlserver}/yum/JNJ-rhel-x86_64-server-7-201703
sslverify=0
#sslcacert=/etc/pki/tls/certs/rootca2048bit.pem
gpgcheck=1
enabled=1
EOF

cat > /etc/yum.repos.d/JNJ-rhel-x86_64-server-optional-7-201703.repo <<-EOF
[JNJ-rhel-x86_64-server-optional-7-201703]
name=JNJ-rhel-x86_64-server-optional-7-201703
baseurl=http://${dmlserver}/yum/JNJ-rhel-x86_64-server-optional-7-201703
sslverify=0
#sslcacert=/etc/pki/tls/certs/rootca2048bit.pem
gpgcheck=1
enabled=1
EOF

cat > /etc/yum.repos.d/JNJ-rhn-tools-rhel-x86_64-server-7-201703.repo <<-EOF
[JNJ-rhn-tools-rhel-x86_64-server-7-201703]
name=JNJ-rhn-tools-rhel-x86_64-server-7-201703
baseurl=http://${dmlserver}/yum/JNJ-rhn-tools-rhel-x86_64-server-7-201703
sslverify=0
#sslcacert=/etc/pki/tls/certs/rootca2048bit.pem
gpgcheck=1
enabled=1
EOF


cat > /etc/yum.repos.d/RHEL7_3_Agents.repo <<-EOF
[RHEL7_3_Agents]
name=RHEL7_3_Agents repo for J&J agents
baseurl=http://${dmlserver}/yum/RHEL7_3_Agents/x86_64/
gpgcheck=0
enabled=1
EOF

