#!/bin/bash
###################################
## This script will check if pre-requisites exist for
## RHEL7 to update 3 (RHEL7.3)

EXITCODE=0
source /etc/jnj-install/config
# Determine current kernel version
KERNEL=$(uname -r)
CURRENTKERNEL=${KERNEL%-*}
echo Set CURRENTKERNEL to ${CURRENTKERNEL}

echo
echo $(date +%T)
REDHAT_VERSION=$(rpm -qa --queryformat '%{VERSION}\n' 'redhat-release-server' | awk -F. '{print $1}' | cut -c1)
echo "Current Red Hat version is ${REDHAT_VERSION}"
if [[ ${REDHAT_VERSION} != 7 ]] ; then
  echo "ERROR: $(hostname) Cannot patch to RHEL 7.3"
  EXITCODE=1
fi

echo
echo $(date +%T)
echo "Checking for LinuxShield..."
rpm -q MFEcma
if [[ $? -eq 0 ]] ; then
  echo "ERROR: $(hostname) LinuxShield Installed"
  EXITCODE=1
fi

echo
echo $(date +%T)
echo "Checking disk space requirements"
root_avail=$(df --direct -m / | tail -1 | awk '{print $4}')
if [[ ${root_avail} -lt 1000 ]] ; then
  echo "ERROR: $(hostname) insufficient space available in /"
  EXITCODE=1
fi
boot_avail=$(df --direct -m /boot | tail -1 | awk '{print $4}')
if [[ ${boot_avail} -lt 20 ]] ; then
  echo "ERROR: $(hostname) insufficient space available in /boot"
  EXITCODE=1
fi
tmp_avail=$(df --direct -m /tmp | tail -1 | awk '{print $4}')
if [[ ${tmp_avail} -lt 1000 ]] ; then
  echo "ERROR: $(hostname) insufficient space available in /tmp"
  EXITCODE=1
fi
var_avail=$(df --direct -m /var | tail -1 | awk '{print $4}')
if [[ ${var_avail} -lt 1200 ]] ; then
  echo "ERROR: $(hostname) insufficient space available in /var"
  EXITCODE=1
fi

echo
echo $(date +%T)
echo "checking satellite registration"
if [ -f /etc/sysconfig/rhn/systemid ] ; then
  rhn_base=$(rhn-channel -b)
  if [ "${rhn_base}" != "JNJ-rhel-x86_64-server-7.2" ]; then
    echo "ERROR: Current channel registration is ${rhn_base}"
    EXITCODE=1
  fi
fi

if [[ ${EXITCODE} -ne 0 ]] ; then
  echo "ERROR: $(hostname) RHEL 7.3 Pre-Check failures found."
  exit 1
else
  echo "$(hostname) ready for RHEL7.3 patching."
  exit 0
fi
