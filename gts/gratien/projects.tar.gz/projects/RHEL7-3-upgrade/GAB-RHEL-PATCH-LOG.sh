#! /bin/bash
########################################################################
# Script Name          : GAB-RHEL7-LOG-3.00.sh
# Author               : Akshay Orpe
# Creation Date        : 25-Apr-2017
########################################################################


# turn on debugging
set -x

cat > logs.txt << EOF
.PH "'==HOSTNAME=='"
.PF "'\\*(DT''page % of ==TOTAL_PAGES=='"
.ev printout
.ns
.ps 8
.vs 9
.ft C
.nf
.ev
.de Ps
.br
.ev printout
.sp \\n[PD]u
.ie !'\\\\\$1'' .in +\\\\\$1n
.el .in +5n
..
.de Pe
.br
.if '\\\\\$1'' .sp \\\\n[PD]u
.in
.ev
..
.ds HP 14 14 12
.ds HF 3 3 3
.ls 10
.S 18
.ce
Update of Red Hat Enterprise Linux 7 to release 7.3.00
.ce
Evidence file for ==HOSTNAME==
.ls
.S D
.SK
.\"###################
.H 1 "/etc/jnj-install/config"
The parameters used in the installation
.Ps
#INSERT /etc/jnj-install/config#
.Pe
EOF

for FN in `ls -rt /var/adm/install-logs/update-7.3.00-*/*.log`
do 
BN=$(basename $FN)
cat >> logs.txt << EOF
.H 1 "${BN}"
.Ps
#INSERT ${FN}#
.Pe
.\"###################
EOF
done

cp logs.txt logs.txt.orig

conv_file()
{
bn=logs_$(basename $1)
sed = $1 | sed 'N; s/^/     /; s/ *\(.\{5,\}\)\n/\1  /' | fold --width=100 > $bn
sed -e "\#INSERT $1# { r $bn" -e "d }" - 
echo
}

gen_ps()
{
cat logs.txt \
  | sed "s/==TOTAL_PAGES==/$total_pages/" \
  | sed "s/==HOSTNAME==/$(hostname)/" \
  | groff -p -mm - >logs.ps
}

grep "#INSERT" logs.txt | sed -e "s/#//g" -e "s/INSERT //" | while read i
do
  cat logs.txt | conv_file $i > logs.txt.tmp
  mv logs.txt.tmp logs.txt
done

total_pages=999
gen_ps
total_pages=$(grep Pages logs.ps | cut -d: -f2)

# The gen_ps function requires groff package - on RHEL 7.2 we only have the groff-base installed,
# but groff is part of the optional repo which is not standard available -> a blocker to create a PS file
if !  rpm -q groff 2>/dev/null 1>&2 ; then
    echo Install groff package required to generate postscript file
    yum -y install groff
fi

gen_ps

# before convert ps to pdf check if we have the ps2pdf executable (part of ghostscript package)
if ! type ps2pdf 1>/dev/null ; then
    echo Install ghostscript package required for ps2pdf
    yum -y install ghostscript
fi

# convert ps document to pdf file
ps2pdf logs.ps logs.pdf

# Because /var/adm/install-logs is not readable for others we better make a copy
# of the logs.pdf to the tmp directory with a more meaningfull filename
cp logs.pdf /tmp/RHEL_update_logs_$(hostname).pdf
chmod 644 /tmp/RHEL_update_logs_$(hostname).pdf
