source /etc/jnj-install/config
export SUPPRESS_STDOUT=yes
mkdir -p /var/adm/install-logs/update-7.3.00-evidence
export logdir=/var/adm/install-logs/update-7.3.00-evidence

cd $logdir

# enable logging
set -x

# grab qualification script
wget ${dmlurl}/scripts/GAB-RHEL-PATCH-LOG.sh -O ${logdir}/GAB-RHEL-PATCH-LOG.sh
chmod 755 ${logdir}/GAB-RHEL-PATCH-LOG.sh

echo `date +%T`: sosreport >> /dev/console
sosreport --batch --alloptions -k selinux.fixfiles=off -k selinux.list=off --tmp-dir=${logdir} &> ${logdir}/sosreport.$(date +%Y%m%d-%H%M%S).log
echo `date +%T`: GAB-RHEL-PATCH-LOG.sh >> /dev/console
bash ${logdir}/GAB-RHEL-PATCH-LOG.sh

mail -s "[`hostname`] 7.3.00 update evidence " -a logs.pdf root < /dev/null

# dump dmidecode info
/usr/sbin/dmidecode > ${logdir}/dmidecode.install

# make all logging readonly
chmod 555 ${logdir}
chmod 444 ${logdir}/*
