#!/bin/bash
###################################
## This script is for patching
## RHEL7.2 to update 7.3 (RHEL7.3)

# Trap on Error
set -e

## Variables
########################################################################
# sourced from /etc/jnj-install/config
# listed in the configvars variable on next line
configvars="dmlurl"

# Source the /etc/jnj-install/config file
# Exit if the /etc/jnj-install/config file is not found
if [ ! -f /etc/jnj-install/config ]; then
  echo "ERROR: /etc/jnj/config file not found."
  exit 1
else
  source /etc/jnj-install/config
fi

for configvar in ${configvars}
do
  if [[ -z $(eval "echo \$$configvar") ]]; then
    echo "ERROR: ${configvar} not defined in /etc/jnj-install/config."
    exit 1
  fi
done

## Logging
#####################################################################
logdir=${logdir:-/var/adm/install-logs}
[[ -d $logdir ]] || mkdir -p $logdir
logfile=$logdir/${0##*/}.$(date +%Y%m%d-%H%M%S).log
exec 3>&1 4>&2
trap 'exec 2>&4 1>&3' 0 1 2 3
exec 1>${logfile} 2>&1

tempdir=$(mktemp -d /tmp/jnjtmp.XXXXXXXXXX)
cd ${tempdir}

#syslog
logger -s -- "[$$] $0 start: $(date)"
logger -s -- "[$$] script started in $(pwd)"
logger -s -- "[$$] logfile is in $logfile"

export PS4="+ [\t] "

## Functions
#####################################################################

function cleanup_before_exit() {
  logger -s -- "[$$] $0 end :  $(date)"
  echo "$0 end: $(date)" >&3
  if [[ "${err}" != "0" ]] ; then
    cat ${logfile} >&3
  fi
  cd /tmp && rm -rf ${tempdir}
}

## Main
#####################################################################
trap cleanup_before_exit EXIT
echo "$0 start: $(date)" >&3

if [[ -f /etc/jnj-install/config ]] ; then
  source /etc/jnj-install/config
else
  echo "ERROR: Missing /etc/jnj-install/config file."
  exit 1
fi

BUNDLE=RHEL7-update-7.3.00
EXPECTEDKERNEL=3.10.0-514.10.2.el7

echo
echo Update the major version number in /etc/jnj-install/config
echo

# Update dmlurl variable in /etc/jnj-install/config and ensure link exist
DATESTAMP=$(date +%F%H%M%S)
sed -i.${DATESTAMP} -e "/^dmlurl=/s/RHEL7.*/RHEL7\/7.3.00/g" /etc/jnj-install/config
if [ ! -s /etc/jnj-install.cfg ] ; then
  ln -s /etc/jnj-install/config /etc/jnj-install.cfg
fi
source /etc/jnj-install/config

echo
echo Download and run RHEL7.3-patch-pre-check.sh script
echo

wget ${dmlurl}/scripts/RHEL7.3-patch-pre-check.sh -O RHEL7.3-patch-pre-check.sh
chmod 755 RHEL7.3-patch-pre-check.sh
bash RHEL7.3-patch-pre-check.sh

if [[ $? -ne 0 ]] ; then
  echo "ERROR: Prerequisite check for RHEL 7.3 patching failed."
  exit 1
fi



# Disable existing yum repos
echo
echo $(date +%T)

rhn-channel --list && reg_sat="TRUE" || reg_sat="FALSE"
if [[ "${reg_sat}" == "TRUE" ]] ; then
  for repo in `ls /etc/yum.repos.d/*.repo` ; do
    mv ${repo} ${repo}.$(date +%F.%H%M)
  done
else
  yum-config-manager --disable
  wget ${dmlurl}/scripts/GAB-RHEL-RPO.sh -O /var/adm/install-logs/autobuild/GAB-RHEL-RPO.sh
 # /bin/bash /var/adm/install-logs/autobuild/GAB-RHEL-RPO.sh
  /bin/bash /home/gdhaese1/projects/RHEL7-3-upgrade/GAB-RHEL-RPO.sh
fi

echo
echo
echo Installing Patch bundle ${BUNDLE} with kernel ${EXPECTEDKERNEL}
echo

echo
echo $(date +%T)
echo Set parameters

# Determine current kernel version
KERNEL=$(uname -r)
CURRENTKERNEL=${KERNEL%-*}
echo Set CURRENTKERNEL to ${CURRENTKERNEL}

echo
echo $(date +%T)
REDHAT_VERSION=$(rpm -qa --queryformat '%{VERSION}\n' 'redhat-release-server' | awk -F. '{print $1}' | cut -c1)
echo "Current Red Hat version is ${REDHAT_VERSION}"
if [[ ${REDHAT_VERSION} != 7 ]] ; then
  echo "Cannot patch to RHEL 7.3"
  exit 1
else
  echo "Continuing with RHEL 7.3 patching."
fi

echo
echo $(date +%T)
echo Turning off anti-virus software during patching
service ds_agent status && service ds_agent stop

echo
echo $(date +%T)
echo Save current list of packages in pre-7.3.00.rpmlist
# Don't overwrite
[[ -f pre-7.3.00.rpmlist ]] || rpm -qa | sort > pre-7.3.00.rpmlist

echo
echo $(date +%T)
echo Save grub configuration
# Don't overwrite
[[ -f /boot/grub2/grub.cfg.7.2.00 ]] || cp -p /boot/grub2/grub.cfg /boot/grub2/grub.cfg.7.2.00

set +e
echo
echo $(date +%T)
echo Listing current repositories:
yum clean all
yum repolist -v
yum -y update subscription-manager python-rhsm

set -e

echo
echo $(date +%T)
echo Install kernel update
yum -y update kernel kernel-devel kernel-doc kernel-headers

# find latest kernel-devel installed
NEWKERNEL=$(rpm -q --queryformat "%{BUILDTIME} %{VERSION}-%{RELEASE}\n" kernel-devel | tail -1 | awk '{print $2}')

echo
echo $(date +%T)
echo Check kernel-devel version
if [[ ${NEWKERNEL} != ${EXPECTEDKERNEL} ]]; then
  echo ================================================================
  echo The installed kernel-devel ${NEWKERNEL} is
  echo  NOT the expected kernel-devel ${EXPECTEDKERNEL}
  echo Please investigate before continuing.
  echo Exiting...
  echo ================================================================
  exit 1
else
  echo Correct new kernel-devel installed, proceeding
fi

echo
echo $(date +%T)
echo Installed kernel RPMs:
echo \(output should show both old and new versions for every kernel package\)
rpm -qa | grep ^kernel-\* | grep -v kernel-firmware | grep -v kernel-abi-whitelists | sort

echo
echo $(date +%T)
echo Check installed kernels
DO_EXIT=0
for rpm in $(rpm -qa | grep ^kernel | grep -v kernel-firmware | grep -v kernel-abi-whitelists | sed "s/-514.10.2-.*//" | sort -u)
do
  if ! rpm -q ${rpm}; then
    DO_EXIT=1
  fi
done
if [[ $DO_EXIT = 1 ]]; then
  echo =======================================
  echo Not All new kernels installed correctly
  echo Exiting...
  echo =======================================
  exit 1
else
  echo "All OK, proceeding"
fi

echo
echo $(date +%T)
echo Do the actual non-kernel updates without rebooting
yum check-update || echo "Software updates available."
yum -y update

echo
echo $(date +%T)
echo Testing if still available updates.
if ! yum -q check-update; then
  echo ============================================================
  echo After update, there are still updates available - not normal
  echo ============================================================
  yum check-update
  echo ============================================================
  echo Please investigate issue before continuing
  echo Exiting...
  echo ============================================================
  exit 1
else
  echo "No updates are available."
fi

echo
echo $(date +%T)
echo "Do further update tasks..."

export SUPPRESS_STDOUT=yes
export logdir

echo
echo $(date +%T)
echo "Set build version to 7.3.00"
sed -i -e "/^buildver=/s/$/,7.3.00/" /etc/jnj-install/config
echo "Set epoip to N/A"
sed -i -e "/^epoip=/s/epoip=.*/epoip=N\/A/g" /etc/jnj-install/config
echo "Set ovoserver to N/A"
sed -i -e "/^ovoserver=/s/ovoserver=.*/ovoserver=N\/A/g" /etc/jnj-install/config
echo "Set hpsimserver to N/A for virtual guests"

# put qualification script on autorun location
# will be run later manually via 'service autoyast start' in CL
wget ${dmlurl}/scripts/GAB-RHEL-PATCH-QUA.sh -O ${logdir}/GAB-RHEL-PATCH-QUA.sh
chmod 700 ${logdir}/GAB-RHEL-PATCH-QUA.sh
# Next line will not work on RHEL 7 (need systemd script instead - run manually if required)
# ln -s ${logdir}/GAB-RHEL-PATCH-QUA.sh /etc/rc.d/GAB-RHEL-QUA.sh

# Furthermore, GAB-RHEL-PATCH-QUA.sh will download GAB-RHEL-PATCH-LOG.sh which
# will not work on RHEL 7.2 due to missing groff and ghostscript packages unless
# we install these packages manually

# Fix / revert changes made during patching to ITS standard build.
#sed -i "s#/sbin/shutdown -r now#/usr/bin/logger#" /etc/init/control-alt-delete.conf
systemctl mask ctrl-alt-delete.target

# Ensure default runlevel is 3
#sed -i -e "/^id:/s/2/3/g" /etc/inittab
systemctl set-default runlevel3.target




echo
echo "The installation of the OS patch bundle"
echo "with kernel ${EXPECTEDKERNEL} was successful."
echo "Reboot to complete the patching process."

# Clean exit
exit 0
