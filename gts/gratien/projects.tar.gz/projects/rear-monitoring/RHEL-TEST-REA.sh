#!/usr/bin/env bash
########################################################################
# Script Name          : RHEL-TEST-REA.sh
# Author               : SAM
# Creation Date        : 03-MAY-2016
# Description          : Test ReaR Agent Installation in
#                        Red Hat Enterprise Linux
# Change History       : Review git log for history of changes
########################################################################

# variables
err=0

# Exit if the config file is not found
if [ ! -f /etc/jnj-install/config ]; then
  echo "ERROR: /etc/jnj-install/config file missing"
  echo "Error at or near line ${LINENO} :  File Not Found"
  exit 1
else
  source /etc/jnj-install/config
fi

## Logging
#####################################################################
logdir=${logdir:-/var/adm/install-logs}
[[ -d $logdir ]] || mkdir -p $logdir
logfile=$logdir/${0##*/}.$(date +%Y%m%d-%H%M%S).log
exec 3>&1 4>&2
trap 'exec 2>&4 1>&3' 0 1 2 3
exec 1>${logfile} 2>&1

tempdir=$(mktemp -d /tmp/jnjtmp.XXXXXXXXXX)
cd ${tempdir}

#syslog
logger -s -- "[$$] $0 start: $(date)"
logger -s -- "[$$] script started in $(pwd)"
logger -s -- "[$$] logfile is in $logfile"

export PS4="+ [\t] "

### Functions
#####################################################################

function cleanup_before_exit() {
  logger -s -- "[$$] $0 end :  $(date)"
  cd /tmp && rm -rf ${tempdir}
}
trap cleanup_before_exit EXIT

echo "$0 start: $(date)" >&3

# Run time
echo "checking for ReaR Agent."

# Check if rear rpm. Exit if agent is not found
if rpm -q rear; then
  echo "ReaR Agent Installed"
else
  echo "ReaR Agent is 'Not Installed'"
  echo "Install the Agent and run again"
  exit 0
fi

# Check for required rpms for ReaR.
for pkg in nfs-utils syslinux genisoimage redhat-lsb-core
do
  if rpm -q ${pkg} 1>/dev/null 2>&1 ; then
    echo "${pkg} is installed"
  else
    echo "ERROR: (Line#${LINENO}) Required rpm - ${pkg} not found"
        let err++;
  fi
done

# Check for required services for ReaR
for _myService in nfs-client.target
do
  if [[ "$(systemctl is-enabled ${_myService})" == "enabled"  && "$( systemctl is-active ${_myService})" == "active" ]]; then
    echo "${_myService} is enabled"
  else
    echo "ERROR: (Line#${LINENO}) ${_myService} not enabled or active"
    let err++;
  fi
done

# find out which ReaR version we have installed
rear_ver=$( rpm -q rear|cut -d- -f2 )


# Files required by ReaR agent
for _myFile in /etc/rear/site.conf /etc/rear/local.conf /var/lib/rear/recovery.sh /var/lib/rear/net_reconfig.sh /etc/cron.weekly/rear
do
  if [ ! -f ${_myFile} ];then
    echo "ERROR: (Line#${LINENO}) ${_myFile} Not Found"
        let err++;
  fi
done

if [[ $rear_ver < 2 ]] ; then
    for _myFile in /usr/share/rear/rescue/GNU/Linux/99_sysreqs.sh /usr/share/rear/finalize/Fedora/i386/16_lvm.conf.sh
    do
        if [ ! -f ${_myFile} ];then
            echo "ERROR: (Line#${LINENO}) ${_myFile} Not Found"
                let err++;
        fi
    done
fi


# Check rear functionality
# If checklayout returns 0 system is in sync with rescue image
# If mkrescue is executed successfully in GAB-RHEL-REA this will return 0
/usr/sbin/rear checklayout
if [[ $? -eq 0 ]]; then
  echo "Rear is working fine"
else
  echo "ERROR: (Line#${LINENO}) Rescue image is not in sync"
fi

if [[ ${err} -eq 0 ]]; then
 echo "ReaR Agent Installation / verfication is successfull"
 echo "ReaR Agent Installation / verfication is successfull" >&3
else
  echo "ReaR Agent Installation / verfication is failed with $err error(s)"
  echo "ReaR Agent Installation / verfication is failed with $err error(s)" >&3
fi
