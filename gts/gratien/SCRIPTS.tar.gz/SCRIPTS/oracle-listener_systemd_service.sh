#!/bin/bash

# This script configures systemd startup service for Oracle default listener Instance
# Wayne Corelli

if [[ $(whoami) != "root" ]]; then
   echo "ERROR: root login required!"
   exit
fi

if [[ $(uname -s) != "Linux" ]]; then
   echo "ERROR: This is not Linux!"
   exit
fi

if [[ $(ps -e|grep " 1 ?"|cut -d " " -f15) != "systemd" ]]; then
   echo "ERROR: Systemd is not present, use InitV scripts instead!"
   exit
fi

echo '# /etc/systemd/system/oracle-listener.service
#   Invoking Oracle scripts to start/shutdown Listener

[Unit]
Description=Oracle Listener(s) with local scripts
Requires=network.target
After=network.target

[Service]
Type=forking
TimeoutStartSec=5min
TimeoutStopSec=3min
RemainAfterExit=yes
Restart=no
ExecStart=/etc/systemd/system/oracle-listener.service.d/oracle-listener.sh start
ExecStop=/etc/systemd/system/oracle-listener.service.d/oracle-listener.sh stop
User=oracle

[Install]
WantedBy=multi-user.target
' > /etc/systemd/system/oracle-listener.service

chmod 644 /etc/systemd/system/oracle-listener.service

mkdir -p -m 0755 /etc/systemd/system/oracle-listener.service.d

echo '# Oracle Listener Configuration
# Required by /etc/systemd/system/oracle-listener.service

[Unit]
Description=Oracle Listener Configuration

[Service]
User=oracle
Group=dba' > /etc/systemd/system/oracle-listener.service.d/oracle-listener.conf

chmod 644 /etc/systemd/system/oracle-listener.service.d/oracle-listener.conf

echo '#!/bin/sh
# Script: /etc/systemd/system/oracle-listener.service.d/oracle-listener.sh
ARG1=$1
source $HOME/.bash_profile
PGM_PATH=$0

case "${ARG1}" in
        start )
                ${ORACLE_HOME}/bin/lsnrctl start LISTENER 
        ;;
        stop )
                ${ORACLE_HOME}/bin/lsnrctl stop LISTENER 
        ;;
        * )
                echo "Usage: ${PGM_PATH} {start|stop}"
        ;;
esac;
' > /etc/systemd/system/oracle-listener.service.d/oracle-listener.sh

chmod 0755 /etc/systemd/system/oracle-listener.service.d/oracle-listener.sh

systemctl daemon-reload
systemctl enable oracle-listener
echo "Done! Service oracle-listener has been configured and will be started during next boot."
echo "If you want to start service now, execute: 
		systemctl start oracle-listener"
echo ""
chkconfig --list 2>/dev/null | grep -q localOracle
if [[ $? -eq 0 ]]; then
    # SYSV init script (/etc/init.d/localOracle) was found activated
    echo "De-activate SYSV localOracle init script for next reboot"
    chkconfig localOracle off
    chkconfig --del localOracle
    echo "If you want to stop manually the localOracle SYSV process now type:
    service localOracle stop"
fi
