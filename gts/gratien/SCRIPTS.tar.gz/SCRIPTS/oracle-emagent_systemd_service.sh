#!/bin/bash
# Define AGENT_INSTANCE_HOME if known.
AGENT_INSTANCE_HOME=/oem/agent_12c/agent_inst

# This script configures systemd startup service for OEM Agent Instance
# Wayne Corelli

if [[ $(whoami) != "root" ]]; then
   echo "ERROR: root login required!"
   exit
fi

if [[ $(uname -s) != "Linux" ]]; then
   echo "ERROR: This is not Linux!"
   exit
fi

if [[ $(ps -e|grep " 1 ?"|cut -d " " -f15) != "systemd" ]]; then
   echo "ERROR: Systemd is not present, use InitV scripts instead!"
   exit
fi

#echo
#echo "Enter AGENT_INSTANCE_HOME of Oracle Enterprise Manager Agent [$AGENT_INSTANCE_HOME]:"
#read NEWHOME
#

case "$NEWHOME" in
     "")         AGENT_INSTANCE_HOME="$AGENT_INSTANCE_HOME" ;;
     *)          AGENT_INSTANCE_HOME="$NEWHOME" ;;
esac

if [[ -z "$AGENT_INSTANCE_HOME" ]]; then
   echo "ERROR: Missing value for AGENT_INSTANCE_HOME!"
   exit
fi

if [[ ! -d "$AGENT_INSTANCE_HOME" ]]; then
    echo "ERROR: Oracle OEM not installed."
    exit 1
fi

getent passwd monora >/dev/null
if [[ $? -gt 0 ]] ; then
    echo "ERROR: User monora is not defined."
    exit 1
fi


echo '# /etc/systemd/system/oracle-emagent.service
#   Invoking Oracle Enterprise Manager to start/shutdown agent
#   monora user account required - is an AD account so we need centrifydc to be active

[Unit]
Description=Oracle Enterprise Manager (emagent)
Requires=network.target centrifydc.service
After=local-fs.target network.target remote-fs.target autofs.service centrifydc.service

[Service]
Type=forking
Restart=no
User=monora
TimeoutStartSec=5min
TimeoutStopSec=3min
RemainAfterExit=yes
ExecStart=/etc/systemd/system/oracle-emagent.service.d/oracle-emagent.sh start
ExecStop=/etc/systemd/system/oracle-emagent.service.d/oracle-emagent.sh stop

[Install]
WantedBy=multi-user.target
' > /etc/systemd/system/oracle-emagent.service

chmod 644 /etc/systemd/system/oracle-emagent.service

mkdir -p -m 0755 /etc/systemd/system/oracle-emagent.service.d

echo '# Oracle Enterprise Manager configuration 
# Required by /etc/systemd/system/oracle-emagent.service

[Unit]
Description=Oracle Enterprise Manager configuration

[Service]
User=monora
' > /etc/systemd/system/oracle-emagent.service.d/oracle-emagent.conf

chmod 644 /etc/systemd/system/oracle-emagent.service.d/oracle-emagent.conf

echo '#!/bin/sh
# Script: /etc/systemd/system/oracle-emagent.service.d/oracle-emagent.sh
ARG1=$1
source $HOME/.bash_profile
PGM_PATH=$0

case "${ARG1}" in
        start )
                $AGENT_INSTANCE_HOME/bin/emctl start agent
			# We do not want a fail code from stop blackout below returned to systemd
			# So we capture the RC of starting the agent.
			# There maybe no black out to remove, this would retunr a none zero RC to systemd.
                RC=$? 
                $AGENT_INSTANCE_HOME/bin/emctl stop blackout "Server Bounce"
                exit $RC
        ;;
        stop )
                $AGENT_INSTANCE_HOME/bin/emctl start blackout "Server Bounce" -nodeLevel -d 0 02:00
                $AGENT_INSTANCE_HOME/bin/emctl stop agent
        ;;
        * )
                echo "Usage: ${PGM_PATH} {start|stop}"
        ;;
esac;
' > /etc/systemd/system/oracle-emagent.service.d/oracle-emagent.sh

chmod 0755 /etc/systemd/system/oracle-emagent.service.d/oracle-emagent.sh

systemctl daemon-reload
systemctl enable oracle-emagent

echo "Done! Service oracle-emagent has been configured and will be started during next boot."
echo "If you want to start service now, execute: 
		systemctl start oracle-emagent"
echo ""
echo "+++++++ Edit /home/monora/.bash_profile +++++++++"
echo 'Add following files:

export AGENT_INSTANCE_HOME='$AGENT_INSTANCE_HOME'
export PATH=/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin
export PATH=$PATH:$HOME/.local/bin:$HOME/bin:$AGENT_INSTANCE_HOME
'
