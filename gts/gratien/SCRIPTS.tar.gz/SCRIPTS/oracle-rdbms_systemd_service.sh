#!/usr/bin/bash
# Define ORACLE SID & ORACLE_HOME if known.
ORACLE_SID=JHHQ0055
ORACLE_HOME=/u01/app/oracle/product/12.1.0.2.161018

# This script configures systemd startup service for Oracle DB Instance
# Wayne Corelli

if [[ $(whoami) != "root" ]]; then
   echo "ERROR: root login required!"
   exit
fi

if [[ $(uname -s) != "Linux" ]]; then
   echo "ERROR: This is not Linux!"
   exit
fi

if [[ $(ps -e|grep " 1 ?"|cut -d " " -f15) != "systemd" ]]; then
   echo "Systemd is not present, use Init scripts instead!"
   exit
fi

getent passwd oracle >/dev/null
if [[ $? -gt 0 ]] ; then
    echo "ERROR: User oracle is not defined."
    exit 1
fi

#echo "List of existing Oracle Homes:"
#echo "------------------------------"
#cat `cat /etc/oraInst.loc|grep inventory_loc|cut -d '=' -f2`/ContentsXML/inventory.xml|grep "HOME NAME"|cut -d '"' -f 4
#echo
#echo "Enter ORACLE_HOME of Oracle [$ORACLE_HOME]:"
#read NEWHOME

#echo "Enter ORACLE_SID of Oracle [$ORACLE_SID]:"
#read NEWSID

case "$NEWHOME" in
     "")         ORAHOME="$ORACLE_HOME" ;;
     *)          ORAHOME="$NEWHOME" ;;
esac

case "$NEWSID" in
     "")         ORASID="$ORACLE_SID" ;;
     *)          ORASID="$NEWSID" ;;
esac

if [[ -z "$ORAHOME" ]]; then
   echo "Error: Missing value for ORAHOME!"
   exit
fi
if [[ ! -d "$ORAHOME" ]]; then
   echo "Error: $ORACLE_HOME does not exist" 
   exit 1
fi


### We are good to install our services

echo '# /etc/systemd/system/oracle-rdbms.service
#   Invoking Oracle scripts to start/shutdown Instances defined in /etc/oratab

[Unit]
Description=Oracle Database(s) with local scripts
Requires=network.target

[Service]
Type=forking
Restart=no
TimeoutStartSec=5min
TimeoutStopSec=3min
RemainAfterExit=yes
ExecStart=/etc/systemd/system/oracle-rdbms.service.d/oracle-rdbms.sh start
ExecStop=/etc/systemd/system/oracle-rdbms.service.d/oracle-rdbms.sh stop
User=oracle

[Install]
WantedBy=multi-user.target
' > /etc/systemd/system/oracle-rdbms.service

chmod 644 /etc/systemd/system/oracle-rdbms.service

mkdir -p -m 0755 /etc/systemd/system/oracle-rdbms.service.d

echo '[Unit]
Description=Oracle Database <'$ORACLE_SID'> with local scripts
Requires=network.target

[Service]
User=oracle
Group=dba' > /etc/systemd/system/oracle-rdbms.service.d/oracle-rdbms.conf

chmod 644 /etc/systemd/system/oracle-rdbms.service.d/oracle-rdbms.conf

# Change 'echo' into 'cat' because line DB_STATUS failed with awk {print } error
cat > /etc/systemd/system/oracle-rdbms.service.d/oracle-rdbms.sh <<EOSCRIPT
#!/bin/sh
ARG1=\$1
source \$HOME/.bash_profile
PGM_PATH=\$0

export TNS_ADMIN=\${ORACLE_BASE}/admin/${ORASID}/tns_admin
PASSWD=\$( grep ^${ORASID}: \${ORACLE_BASE}/admin/${ORASID}/scripts/.instance_pwd | cut -d: -f2 )
export PASSWD
STATUS_LIMIT="ACTIVE"

case "\${ARG1}" in
        start )
                sqlplus /nolog << EOF
                connect / as sysdba
                startup mount;
                alter system set encryption wallet open identified by "\$PASSWD";
                exit
EOF

                sqlplus -s / as sysdba << EOF >> /tmp/check_backup_mode.log
                set pages 0 serverout on feed off
                select distinct STATUS from v\$backup;
                exit
EOF

                DB_STATUS=\$( tail -1  /tmp/check_backup_mode.log | awk '{print \$1}' )
		rm -f /tmp/check_backup_mode.log

                if [ "\${DB_STATUS}" = "\${STATUS_LIMIT}" ]
                        then
                               sqlplus /nolog << EOF
                               connect / as sysdba
                               alter database end backup;
                               alter database open;
                               exit
EOF
                        else
                               sqlplus /nolog << EOF
                               connect / as sysdba
                               alter database open;
                               exit
EOF
                fi
 ;;
        stop )
                sqlplus /nolog << EOF
                connect / as sysdba
                shutdown immediate
                exit
EOF
 ;;
        * )
                echo "Usage: \${PGM_PATH} {start|stop}"
        ;;
esac;
EOSCRIPT

chmod 0755 /etc/systemd/system/oracle-rdbms.service.d/oracle-rdbms.sh

systemctl daemon-reload
systemctl enable oracle-rdbms
echo "Done! Service oracle-rdbms has been configured and will be started during next boot."

chkconfig --list 2>/dev/null | grep -q localOracle
if [[ $? -eq 0 ]]; then
    # SYSV init script (/etc/init.d/localOracle) was found activated
    echo "De-activate SYSV localOracle init script for next reboot"
    chkconfig localOracle off
    chkconfig --del localOracle
    echo "If you want to stop manually the localOracle SYSV process now type:
    service localOracle stop"
fi

echo ""
echo "If you want to start the SystemD oracle-rdbms service now, execute: 
    systemctl start oracle-rdbms"
echo ""
exit 0
