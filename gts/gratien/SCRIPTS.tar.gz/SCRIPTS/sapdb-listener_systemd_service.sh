#!/bin/bash

# Define SAPSYSTEMNAME if known.
# We can find out the SAPSID automatically if sap software was already installed
if [[ -f /usr/sap/sapservices ]] ; then
    SAPSYSTEMNAME=$( cat /usr/sap/sapservices |grep LD_LIBRARY_PATH|awk '{gsub(/LD_LIBRARY_PATH=/,"",$1); gsub(/\:\$LD_LIBRARY_PATH\;/,"",$1);print $NF}' | cut -c1-3 | tr [:lower:] [:upper:] )
else
    SAPSYSTEMNAME=C30
fi


# This script configures systemd startup service for SAP DB Instance
# Wayne Corelli

if [[ $(whoami) != "root" ]]; then
   echo "ERROR: root login required!"
   exit
fi

if [[ $(uname -s) != "Linux" ]]; then
   echo "ERROR: This is not Linux!"
   exit
fi

if [[ $(ps -e|grep " 1 ?"|cut -d " " -f15) != "systemd" ]]; then
   echo "Systemd is not present, use Init scripts instead!"
   exit
fi

#echo "List of existing SAP Instances in /usr/sap/sapservices :"
#echo "------------------------------------------------------------"
#echo "User    Path"
#echo "------------------------------------------------------------"
#cat /usr/sap/sapservices |grep LD_LIBRARY_PATH|awk '{gsub(/LD_LIBRARY_PATH=/,"",$1); gsub(/\:\$LD_LIBRARY_PATH\;/,"",$1);print $NF, $1}'
#echo "------------------------------------------------------------"
#echo "Enter SAP SID [$SAPSYSTEMNAME]:"
#read NEWSID

case "$NEWSID" in
     "")         SAPSID="$SAPSYSTEMNAME" ;;
     *)          SAPSID="$NEWSID" ;;
esac

if [[ -z "$SAPSID" ]]; then
   echo "ERROR: Missing SAPSID value!"
   exit
fi

if [[ ! -d "/sapmnt/${SAPSID}" ]]; then
   echo "ERROR: Directory 'not' found for SID ${SAPSID}: /sapmnt/$SAPSID" 
   exit 1
fi

##### Good to go

echo '# /etc/systemd/system/sapdb-listener.service
#   Invoking Oracle scripts to start/shutdown Oracle Listener
#

[Unit]
Description=SAP Oracle Instance Listener
Requires=local-fs.target remote-fs.target network.target autofs.service
After=local-fs.target remote-fs.target network.target autofs.service 

[Service]
Type=forking
Restart=no
RemainAfterExit=yes
TimeoutStartSec=5min
TimeoutStopSec=3min
ExecStart=/etc/systemd/system/sapdb-listener.service.d/sapdb-listener.sh start
ExecStop=/etc/systemd/system/sapdb-listener.service.d/sapdb-listener.sh stop

[Install]
WantedBy=multi-user.target
' > /etc/systemd/system/sapdb-listener.service

chmod 644 /etc/systemd/system/sapdb-listener.service

mkdir -p -m 0755 /etc/systemd/system/sapdb-listener.service.d

echo '[Unit]
Description=SAP Oracle Listener '$SAPSID'
ConditionPathExists=!/sapmnt/'$SAPSID'/SAP_NOAUTOSTART

[Service]
User=ora'${SAPSID,,}'
Group=dba' > /etc/systemd/system/sapdb-listener.service.d/sapdb-listener.conf

chmod 644 /etc/systemd/system/sapdb-listener.service.d/sapdb-listener.conf

echo '#!/bin/sh
ARG1=$1
source $HOME/.profile
PGM_PATH=$0

case "${ARG1}" in
        start )
                $ORACLE_HOME/bin/lsnrctl start LISTENER_'${SAPSID}'
        ;;
        stop )
                $ORACLE_HOME/bin/lsnrctl stop LISTENER_'${SAPSID}'
        ;;
        * )
                echo "Usage: ${PGM_PATH} {start|stop}"
        ;;
esac;' > /etc/systemd/system/sapdb-listener.service.d/sapdb-listener.sh

chmod 0755 /etc/systemd/system/sapdb-listener.service.d/sapdb-listener.sh

systemctl daemon-reload
systemctl enable sapdb-listener
echo "Done! Service sapdb-listener has been configured and will be started during next boot."

chkconfig --list 2>/dev/null | grep -q sapautostart
if [[ $? -eq 0 ]]; then
    chkconfig sapautostart off
    chkconfig --del sapautostart
    echo "If this server was running previous SYSV init scripts , FIRST execute:
    		service sapautostart stop"
fi
chkconfig --list 2>/dev/null | grep -q sapinit
if [[ $? -eq 0 ]]; then
    chkconfig sapinit off
    chkconfig --del sapinit
    echo "If this server was running previous SYSV init scripts , FIRST execute:
		service sapinit stop"
fi

echo ""
echo "If you want to start service now, execute: 
      systemctl start sapdb-listener"
echo "**** Check if there is no older start-up script defined under systemctl ****"
systemctl | egrep '(oracle|sap)'

echo ""
exit 0
