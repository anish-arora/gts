#!/bin/bash

# Define SAPSYSTEMNAME if known.
# We can find out the SAPSID automatically if sap software was already installed
if [[ -f /usr/sap/sapservices ]] ; then
    SAPSYSTEMNAME=$( cat /usr/sap/sapservices |grep LD_LIBRARY_PATH|awk '{gsub(/LD_LIBRARY_PATH=/,"",$1); gsub(/\:\$LD_LIBRARY_PATH\;/,"",$1);print $NF}' | cut -c1-3 | tr [:lower:] [:upper:] )
else
    SAPSYSTEMNAME=C30
fi


# This script configures systemd startup service for SAP Instance
# Wayne Corelli

if [[ $(whoami) != "root" ]]; then
   echo "ERROR: root login required!"
   exit
fi

if [[ $(uname -s) != "Linux" ]]; then
   echo "ERROR: This is not Linux!"
   exit
fi

if [[ $(ps -e|grep " 1 ?"|cut -d " " -f15) != "systemd" ]]; then
   echo "Systemd is not present, use Init scripts instead!"
   exit
fi

#echo "List of existing SAP Instances in /usr/sap/sapservices :"
#echo "------------------------------------------------------------"
#echo "User    Path"
#echo "------------------------------------------------------------"
#cat /usr/sap/sapservices |grep LD_LIBRARY_PATH|awk '{gsub(/LD_LIBRARY_PATH=/,"",$1); gsub(/\:\$LD_LIBRARY_PATH\;/,"",$1);print $NF, $1}'
#echo "------------------------------------------------------------"
#echo "Enter SAP SID [$SAPSYSTEMNAME]:"
#read NEWSID

case "$NEWSID" in
     "")         SAPSID="$SAPSYSTEMNAME" ;;
     *)          SAPSID="$NEWSID" ;;
esac

if [[ -z "$SAPSID" ]]; then
   echo "ERROR: Missing SAPSID value!"
   exit
fi

if [[ ! -d "/sapmnt/${SAPSID}" ]]; then
   echo "ERROR: Directory 'not' found for SID ${SAPSID}: /sapmnt/$SAPSID"
   exit 1
fi

echo '# /etc/systemd/system/sapinstance.service
#   Invoking SAP scripts to start/shutdown Instances
#

[Unit]
Description=SAP Instance
Requires=local-fs.target remote-fs.target network.target autofs.service
After=local-fs.target remote-fs.target network.target autofs.service

[Service]
Type=forking
Restart=no
TimeoutStartSec=10min
TimeoutStopSec=3min
RemainAfterExit=yes
ExecStart=/etc/systemd/system/sapinstance.service.d/sapinstance.sh start
ExecStop=/etc/systemd/system/sapinstance.service.d/sapinstance.sh stop

[Install]
WantedBy=multi-user.target' > /etc/systemd/system/sapinstance.service

chmod 644 /etc/systemd/system/sapinstance.service

mkdir -p -m 0755 /etc/systemd/system/sapinstance.service.d

echo '[Unit]
Description=SAP Instance '$SAPSID'
ConditionPathExists=!/sapmnt/'$SAPSID'/SAP_NOAUTOSTART

[Service]
User='${SAPSID,,}'adm
Group=sapsys' > /etc/systemd/system/sapinstance.service.d/sapinstance.conf

chmod 644 /etc/systemd/system/sapinstance.service.d/sapinstance.conf

echo '#!/bin/sh
ARG1=$1
source $HOME/.profile
PGM_PATH=$0
Count=0
RETRYS=10
SLEEP_TIME=60
SLEEP_NOW=0
case "${ARG1}" in
        start )
                while [ $Count -lt $RETRYS ]; do

		sleep $SLEEP_NOW
                $_DEF_EXE2/startsap r3
                RC=$?
                if [ "$RC" -eq 0 ]; then
                        echo "################################################################################"
                        echo "# "$_DEF_EXE2"/startsap r3 completed succesfully return code = "$RC
                        echo "################################################################################"
                        exit $RC
                else
                        let Count=Count+1
                        let Retries=$RETRYS-$Count
                        SLEEP_NOW=$SLEEP_TIME
                        echo "################################################################################"
                        echo "# "$_DEF_EXE2"/startsap r3 failed return code = "$RC
                        echo "# Sleeping "$SLEEP_TIME" seconds, Count = "$Count" Retrying "$Retries" more time(s)"
                        echo "################################################################################"
                fi

                done
                exit $RC
        ;;
        stop )
                $_DEF_EXE2/stopsap r3
		RC=$?
                exit $RC
        ;;
        * )
                echo "Usage: ${PGM_PATH} {start|stop}"
        ;;
esac;' > /etc/systemd/system/sapinstance.service.d/sapinstance.sh

chmod 0755 /etc/systemd/system/sapinstance.service.d/sapinstance.sh

systemctl daemon-reload
systemctl enable sapinstance
echo "Done! Service sapinstance has been configured and will be started during next boot."

chkconfig --list 2>/dev/null | grep -q sapautostart
if [[ $? -eq 0 ]]; then
    chkconfig sapautostart off
    chkconfig --del sapautostart
    echo "If this server was running previous SYSV init scripts , FIRST execute:
                service sapautostart stop"
fi
chkconfig --list 2>/dev/null | grep -q sapinit
if [[ $? -eq 0 ]]; then
    chkconfig sapinit off
    chkconfig --del sapinit
    echo "If this server was running previous SYSV init scripts , FIRST execute:
                service sapinit stop"
fi

echo ""
echo "If you want to start service now, execute:
      systemctl start sapinstance"

echo ""
exit 0
